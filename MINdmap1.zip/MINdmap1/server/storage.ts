import { 
  users, 
  mindMaps, 
  nodes, 
  edges,
  type User, 
  type InsertUser,
  type MindMap,
  type InsertMindMap,
  type Node,
  type InsertNode,
  type Edge,
  type InsertEdge
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Mind map methods
  getMindMap(id: number): Promise<MindMap | undefined>;
  getMindMapsByUserId(userId: number): Promise<MindMap[]>;
  createMindMap(mindMap: InsertMindMap): Promise<MindMap>;
  updateMindMap(id: number, data: Partial<InsertMindMap>): Promise<MindMap | undefined>;
  deleteMindMap(id: number): Promise<boolean>;
  
  // Node methods
  getNodesByMindMapId(mindMapId: number): Promise<Node[]>;
  createNode(node: InsertNode): Promise<Node>;
  updateNode(mindMapId: number, nodeId: string, data: Partial<InsertNode>): Promise<Node | undefined>;
  deleteNode(mindMapId: number, nodeId: string): Promise<boolean>;
  
  // Edge methods
  getEdgesByMindMapId(mindMapId: number): Promise<Edge[]>;
  createEdge(edge: InsertEdge): Promise<Edge>;
  updateEdge(mindMapId: number, edgeId: string, data: Partial<InsertEdge>): Promise<Edge | undefined>;
  deleteEdge(mindMapId: number, edgeId: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Mind map methods
  async getMindMap(id: number): Promise<MindMap | undefined> {
    const [mindMap] = await db.select().from(mindMaps).where(eq(mindMaps.id, id));
    return mindMap;
  }
  
  async getMindMapsByUserId(userId: number): Promise<MindMap[]> {
    return await db.select().from(mindMaps).where(eq(mindMaps.userId, userId));
  }
  
  async createMindMap(mindMap: InsertMindMap): Promise<MindMap> {
    const [newMindMap] = await db.insert(mindMaps).values(mindMap).returning();
    return newMindMap;
  }
  
  async updateMindMap(id: number, data: Partial<InsertMindMap>): Promise<MindMap | undefined> {
    const [updatedMindMap] = await db
      .update(mindMaps)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(eq(mindMaps.id, id))
      .returning();
    return updatedMindMap;
  }
  
  async deleteMindMap(id: number): Promise<boolean> {
    const [deletedMindMap] = await db
      .delete(mindMaps)
      .where(eq(mindMaps.id, id))
      .returning();
    return !!deletedMindMap;
  }
  
  // Node methods
  async getNodesByMindMapId(mindMapId: number): Promise<Node[]> {
    return await db.select().from(nodes).where(eq(nodes.mindMapId, mindMapId));
  }
  
  async createNode(node: InsertNode): Promise<Node> {
    const [newNode] = await db.insert(nodes).values(node).returning();
    return newNode;
  }
  
  async updateNode(mindMapId: number, nodeId: string, data: Partial<InsertNode>): Promise<Node | undefined> {
    const [updatedNode] = await db
      .update(nodes)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(
        and(
          eq(nodes.mindMapId, mindMapId),
          eq(nodes.nodeId, nodeId)
        )
      )
      .returning();
    return updatedNode;
  }
  
  async deleteNode(mindMapId: number, nodeId: string): Promise<boolean> {
    const [deletedNode] = await db
      .delete(nodes)
      .where(
        and(
          eq(nodes.mindMapId, mindMapId),
          eq(nodes.nodeId, nodeId)
        )
      )
      .returning();
    return !!deletedNode;
  }
  
  // Edge methods
  async getEdgesByMindMapId(mindMapId: number): Promise<Edge[]> {
    return await db.select().from(edges).where(eq(edges.mindMapId, mindMapId));
  }
  
  async createEdge(edge: InsertEdge): Promise<Edge> {
    const [newEdge] = await db.insert(edges).values(edge).returning();
    return newEdge;
  }
  
  async updateEdge(mindMapId: number, edgeId: string, data: Partial<InsertEdge>): Promise<Edge | undefined> {
    const [updatedEdge] = await db
      .update(edges)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(
        and(
          eq(edges.mindMapId, mindMapId),
          eq(edges.edgeId, edgeId)
        )
      )
      .returning();
    return updatedEdge;
  }
  
  async deleteEdge(mindMapId: number, edgeId: string): Promise<boolean> {
    const [deletedEdge] = await db
      .delete(edges)
      .where(
        and(
          eq(edges.mindMapId, mindMapId),
          eq(edges.edgeId, edgeId)
        )
      )
      .returning();
    return !!deletedEdge;
  }
}

export const storage = new DatabaseStorage();
