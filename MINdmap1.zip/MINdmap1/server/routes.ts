import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMindMapSchema, insertNodeSchema, insertEdgeSchema } from "@shared/schema";
import { z } from "zod";
import { nanoid } from "nanoid";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post('/api/users', async (req, res) => {
    try {
      const body = req.body;
      
      // Validate request body
      const userSchema = z.object({
        username: z.string().min(3),
        password: z.string().min(6),
        displayName: z.string().optional()
      });
      
      const validatedData = userSchema.parse(body);
      
      const user = await storage.createUser({
        username: validatedData.username,
        password: validatedData.password,
        displayName: validatedData.displayName
      });
      
      // Don't return the password
      const { password, ...userWithoutPassword } = user;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  // Mind Map routes
  app.post('/api/mindmaps', async (req, res) => {
    try {
      const body = req.body;
      
      // Validate request body
      const mindMapSchema = z.object({
        userId: z.number(),
        name: z.string(),
        description: z.string().optional(),
        isPublic: z.boolean().optional()
      });
      
      const validatedData = mindMapSchema.parse(body);
      
      const mindMap = await storage.createMindMap({
        userId: validatedData.userId,
        name: validatedData.name,
        description: validatedData.description,
        isPublic: validatedData.isPublic
      });
      
      res.status(201).json(mindMap);
    } catch (error) {
      res.status(400).json({ message: "Invalid mind map data" });
    }
  });

  // Get mind maps for a user
  app.get('/api/users/:userId/mindmaps', async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID format" });
      }
      
      const mindMaps = await storage.getMindMapsByUserId(userId);
      res.json(mindMaps);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch mind maps" });
    }
  });

  // Get a specific mind map with its nodes and edges
  app.get('/api/mindmaps/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const mindMap = await storage.getMindMap(id);
      
      if (!mindMap) {
        return res.status(404).json({ message: "Mind map not found" });
      }
      
      // Get all nodes and edges for this mind map
      const nodes = await storage.getNodesByMindMapId(id);
      const edges = await storage.getEdgesByMindMapId(id);
      
      res.json({
        ...mindMap,
        nodes,
        edges
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch mind map" });
    }
  });

  // Update a mind map
  app.patch('/api/mindmaps/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const body = req.body;
      
      // Validate request body - allowing partial updates
      const mindMapSchema = z.object({
        name: z.string().optional(),
        description: z.string().optional(),
        isPublic: z.boolean().optional()
      });
      
      const validatedData = mindMapSchema.parse(body);
      
      const updatedMindMap = await storage.updateMindMap(id, validatedData);
      
      if (!updatedMindMap) {
        return res.status(404).json({ message: "Mind map not found" });
      }
      
      res.json(updatedMindMap);
    } catch (error) {
      res.status(400).json({ message: "Invalid mind map data" });
    }
  });

  // Delete a mind map
  app.delete('/api/mindmaps/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteMindMap(id);
      
      if (!success) {
        return res.status(404).json({ message: "Mind map not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete mind map" });
    }
  });

  // Node routes
  app.post('/api/mindmaps/:mindMapId/nodes', async (req, res) => {
    try {
      const mindMapId = parseInt(req.params.mindMapId);
      
      if (isNaN(mindMapId)) {
        return res.status(400).json({ message: "Invalid mind map ID format" });
      }
      
      const body = req.body;
      
      // Check if mind map exists
      const mindMap = await storage.getMindMap(mindMapId);
      if (!mindMap) {
        return res.status(404).json({ message: "Mind map not found" });
      }
      
      // Generate a unique node ID if not provided
      const nodeId = body.nodeId || nanoid();
      
      // Validate request body
      const nodeSchema = z.object({
        type: z.string(),
        positionX: z.number(),
        positionY: z.number(),
        data: z.record(z.any())
      });
      
      const validatedData = nodeSchema.parse(body);
      
      const node = await storage.createNode({
        mindMapId,
        nodeId,
        type: validatedData.type,
        positionX: validatedData.positionX,
        positionY: validatedData.positionY,
        data: validatedData.data
      });
      
      res.status(201).json(node);
    } catch (error) {
      res.status(400).json({ message: "Invalid node data" });
    }
  });

  // Update a node
  app.patch('/api/mindmaps/:mindMapId/nodes/:nodeId', async (req, res) => {
    try {
      const mindMapId = parseInt(req.params.mindMapId);
      const nodeId = req.params.nodeId;
      
      if (isNaN(mindMapId)) {
        return res.status(400).json({ message: "Invalid mind map ID format" });
      }
      
      const body = req.body;
      
      // Validate request body - allowing partial updates
      const nodeSchema = z.object({
        type: z.string().optional(),
        positionX: z.number().optional(),
        positionY: z.number().optional(),
        data: z.record(z.any()).optional()
      });
      
      const validatedData = nodeSchema.parse(body);
      
      const updatedNode = await storage.updateNode(mindMapId, nodeId, validatedData);
      
      if (!updatedNode) {
        return res.status(404).json({ message: "Node not found" });
      }
      
      res.json(updatedNode);
    } catch (error) {
      res.status(400).json({ message: "Invalid node data" });
    }
  });

  // Delete a node
  app.delete('/api/mindmaps/:mindMapId/nodes/:nodeId', async (req, res) => {
    try {
      const mindMapId = parseInt(req.params.mindMapId);
      const nodeId = req.params.nodeId;
      
      if (isNaN(mindMapId)) {
        return res.status(400).json({ message: "Invalid mind map ID format" });
      }
      
      const success = await storage.deleteNode(mindMapId, nodeId);
      
      if (!success) {
        return res.status(404).json({ message: "Node not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete node" });
    }
  });

  // Edge routes
  app.post('/api/mindmaps/:mindMapId/edges', async (req, res) => {
    try {
      const mindMapId = parseInt(req.params.mindMapId);
      
      if (isNaN(mindMapId)) {
        return res.status(400).json({ message: "Invalid mind map ID format" });
      }
      
      const body = req.body;
      
      // Check if mind map exists
      const mindMap = await storage.getMindMap(mindMapId);
      if (!mindMap) {
        return res.status(404).json({ message: "Mind map not found" });
      }
      
      // Generate a unique edge ID if not provided
      const edgeId = body.edgeId || nanoid();
      
      // Validate request body
      const edgeSchema = z.object({
        source: z.string(),
        target: z.string(),
        type: z.string().optional(),
        data: z.record(z.any()).optional()
      });
      
      const validatedData = edgeSchema.parse(body);
      
      const edge = await storage.createEdge({
        mindMapId,
        edgeId,
        source: validatedData.source,
        target: validatedData.target,
        type: validatedData.type,
        data: validatedData.data
      });
      
      res.status(201).json(edge);
    } catch (error) {
      res.status(400).json({ message: "Invalid edge data" });
    }
  });

  // Update an edge
  app.patch('/api/mindmaps/:mindMapId/edges/:edgeId', async (req, res) => {
    try {
      const mindMapId = parseInt(req.params.mindMapId);
      const edgeId = req.params.edgeId;
      
      if (isNaN(mindMapId)) {
        return res.status(400).json({ message: "Invalid mind map ID format" });
      }
      
      const body = req.body;
      
      // Validate request body - allowing partial updates
      const edgeSchema = z.object({
        source: z.string().optional(),
        target: z.string().optional(),
        type: z.string().optional(),
        data: z.record(z.any()).optional()
      });
      
      const validatedData = edgeSchema.parse(body);
      
      const updatedEdge = await storage.updateEdge(mindMapId, edgeId, validatedData);
      
      if (!updatedEdge) {
        return res.status(404).json({ message: "Edge not found" });
      }
      
      res.json(updatedEdge);
    } catch (error) {
      res.status(400).json({ message: "Invalid edge data" });
    }
  });

  // Delete an edge
  app.delete('/api/mindmaps/:mindMapId/edges/:edgeId', async (req, res) => {
    try {
      const mindMapId = parseInt(req.params.mindMapId);
      const edgeId = req.params.edgeId;
      
      if (isNaN(mindMapId)) {
        return res.status(400).json({ message: "Invalid mind map ID format" });
      }
      
      const success = await storage.deleteEdge(mindMapId, edgeId);
      
      if (!success) {
        return res.status(404).json({ message: "Edge not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete edge" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
