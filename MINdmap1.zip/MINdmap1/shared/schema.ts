import { pgTable, text, serial, integer, boolean, jsonb, timestamp, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: varchar("display_name", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// User relations defined after all tables are declared

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Mind maps table schema
export const mindMaps = pgTable("mind_maps", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  isPublic: boolean("is_public").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Mind map relations defined after all tables are declared

export const insertMindMapSchema = createInsertSchema(mindMaps).pick({
  userId: true,
  name: true,
  description: true,
  isPublic: true,
});

export type InsertMindMap = z.infer<typeof insertMindMapSchema>;
export type MindMap = typeof mindMaps.$inferSelect;

// Nodes table
export const nodes = pgTable("nodes", {
  id: serial("id").primaryKey(),
  mindMapId: integer("mind_map_id").references(() => mindMaps.id).notNull(),
  nodeId: varchar("node_id", { length: 50 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  positionX: integer("position_x").notNull(),
  positionY: integer("position_y").notNull(),
  data: jsonb("data").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Node relations defined after all tables are declared

export const insertNodeSchema = createInsertSchema(nodes).pick({
  mindMapId: true,
  nodeId: true,
  type: true,
  positionX: true,
  positionY: true,
  data: true,
});

export type InsertNode = z.infer<typeof insertNodeSchema>;
export type Node = typeof nodes.$inferSelect;

// Edges table
export const edges = pgTable("edges", {
  id: serial("id").primaryKey(),
  mindMapId: integer("mind_map_id").references(() => mindMaps.id).notNull(),
  edgeId: varchar("edge_id", { length: 50 }).notNull(),
  source: varchar("source", { length: 50 }).notNull(),
  target: varchar("target", { length: 50 }).notNull(),
  type: varchar("type", { length: 50 }),
  data: jsonb("data"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Edge relations defined after all tables are declared

export const insertEdgeSchema = createInsertSchema(edges).pick({
  mindMapId: true,
  edgeId: true,
  source: true,
  target: true,
  type: true,
  data: true,
});

export type InsertEdge = z.infer<typeof insertEdgeSchema>;
export type Edge = typeof edges.$inferSelect;

// Define all relations after tables have been declared
export const usersRelations = relations(users, ({ many }) => ({
  mindMaps: many(mindMaps),
}));

export const mindMapsRelations = relations(mindMaps, ({ one, many }) => ({
  user: one(users, {
    fields: [mindMaps.userId],
    references: [users.id],
  }),
  nodes: many(nodes),
  edges: many(edges),
}));

export const nodesRelations = relations(nodes, ({ one }) => ({
  mindMap: one(mindMaps, {
    fields: [nodes.mindMapId],
    references: [mindMaps.id],
  }),
}));

export const edgesRelations = relations(edges, ({ one }) => ({
  mindMap: one(mindMaps, {
    fields: [edges.mindMapId],
    references: [mindMaps.id],
  }),
}));
