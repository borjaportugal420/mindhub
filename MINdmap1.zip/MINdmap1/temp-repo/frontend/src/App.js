import './App.css';
import Mindmap from './components/Mindmap'

function App() {
  return (
    <div style={{height: '100%', width: '100%'}}>
      <Mindmap/>
    </div>
  );
}

export default App;
