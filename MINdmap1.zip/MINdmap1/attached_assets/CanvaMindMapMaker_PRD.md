
# PRD: Canva-Style Mind Map Builder (Notably-Powered)

---

## Summary (For Vibe Coders)

We're building a Canva-inspired Mind Map Maker as a standalone app. The user will drag, drop, and connect nodes in a beautifully styled canvas (glassmorphic), then export, analyze, or sync their maps into Notably. The entire UI is modular and designed for Replit dev mode, then later powered by Notably's data model.

---

## Project Name
**MindMap.Maker (Phase 1)**

---

## Objective

Deliver a fully interactive drag-and-drop mind mapping canvas with visual node editing, connection lines, zoom, and custom node types (images, text, emoji, colors). Final output must be exportable as JSON and optionally saved to Notably for deeper analysis.

---

## Core Features

- Fullscreen canvas with glassmorphic styling
- Drag-to-create nodes
- Connect nodes with lines (flowchart-style)
- Edit node content (text, icons, labels)
- Zoom and pan canvas
- Mini map for navigation
- Export button (to JSON or Notably upload)
- Sidebar for node library + customization
- Dark/light mode toggle

---

## UI Requirements (Canva-Inspired)

- Nodes appear in floating cards with shadows + blur
- Toolbar with tools: add node, connect, delete, style
- Sidebar with templates: Blank, Brainstorm, PRD Builder
- Right panel: node properties and global settings
- TailwindCSS + glassmorphism used throughout

---

## Tech Stack

- Frontend: React (Replit optimized)
- Styling: TailwindCSS with blur, shadows, custom themes
- Canvas: react-flow or D3.js (whichever performs better)
- Optional: Zustand or Redux for state
- Backend Phase 2: Notably SDK or webhook for map-to-doc sync

---

## Manus Prompt #1

> Generate a detailed PRD for a drag-and-drop mind map builder with:
> - Canvas with zoom/pan
> - Node creation and connection
> - Export to JSON
> - TailwindCSS + React structure
> - Responsive UI with glassmorphic elements

---

## Manus Prompt #2

> Write a PRD to convert this mind map into structured markdown format to feed into Notably. Each node becomes a section, connections define hierarchy. Must support both visual and doc-based navigation.

---

## Next Steps

1. Build Replit app with canvas-only layout
2. Implement react-flow or D3 node logic
3. Add export-to-JSON button and test layout saving
4. Design modular node types (title, icon, emoji, tag)
5. Add UI polish and Tailwind styling
6. Prep Notably sync logic (Phase 2)
