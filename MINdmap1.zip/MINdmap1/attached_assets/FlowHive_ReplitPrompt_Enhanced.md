
# Replit Prompt: Streamlined Canva-Style Mind Map Builder

---

## 🎯 Build Goal

Create a seamless, Canva-style mind map system where each node is fully connectable and draggable. All nodes must display full circular connectors (no visual clipping). The connection flow should be intuitive and dynamic like the reference image — with clean transitions, smooth snapping, and fully visual end-to-end connections (no broken lines or half-connectors).

---

## 🖼️ Visual Requirements

- Use `react-flow` or `d3.js` for canvas rendering.
- Node connectors should be full circles, styled with Tailwind for a clean glassmorphic finish.
- Avoid clipping: ensure connectors are not visually cut off when selecting or hovering.

---

## ✨ UX Benchmark

Think of this like if **Canva and Figma built a flowchart tool together**:

- Drag, zoom, pan, auto-align, snap-to-grid
- Responsive on desktop + mobile
- Full-circle connectors on each side of the node
- No glitching when clicking connectors

---

## ✅ Next Steps for Replit Build

1. Rebuild the node component with full circular connectors using Tailwind + SVG.
2. Apply `react-flow` or `d3.js` canvas logic for rendering the connections.
3. Fix connection behavior: ensure every connector has hover, select, and drag states.
4. Test multi-directional node connections (top, bottom, left, right).
5. Add snapping or auto-grid logic (optional polish).

---

## 🧠 Reminder

This is Phase 1 of the larger FlowHive visual agent builder. This UI will later connect with AI helpers and output Cursor/n8n workflows.

