import { Node, Edge } from 'reactflow';

/**
 * Export the current mind map to a JSON structure
 */
export function exportToJson(nodes: Node[], edges: Edge[]) {
  return {
    nodes: nodes.map(({ id, type, position, data }) => ({
      id,
      type,
      position,
      data
    })),
    edges: edges.map(({ id, source, target, type, sourceHandle, targetHandle, style, data }) => ({
      id,
      source,
      target,
      type,
      sourceHandle,
      targetHandle,
      style,
      data
    }))
  };
}

/**
 * Import a mind map from a JSON file
 */
export function importFromJson(file: File): Promise<{ nodes: Node[], edges: Edge[] }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        if (!e.target?.result) {
          throw new Error('Failed to read file');
        }
        
        const result = JSON.parse(e.target.result as string);
        
        if (!result.nodes || !result.edges) {
          throw new Error('Invalid file format: missing nodes or edges');
        }
        
        // Validate nodes and edges
        const nodes = result.nodes.map((node: any) => ({
          id: node.id,
          type: node.type,
          position: node.position,
          data: node.data
        }));
        
        const edges = result.edges.map((edge: any) => ({
          id: edge.id,
          source: edge.source,
          target: edge.target,
          type: edge.type,
          sourceHandle: edge.sourceHandle,
          targetHandle: edge.targetHandle,
          style: edge.style,
          data: edge.data
        }));
        
        resolve({ nodes, edges });
      } catch (error) {
        reject(error);
      }
    };
    
    reader.onerror = (error) => {
      reject(error);
    };
    
    reader.readAsText(file);
  });
}

/**
 * Calculate the bounding box for a set of nodes
 */
export function getNodesBoundingBox(nodes: Node[]) {
  if (nodes.length === 0) return { x: 0, y: 0, width: 0, height: 0 };
  
  const xs = nodes.map(node => node.position.x);
  const ys = nodes.map(node => node.position.y);
  
  const minX = Math.min(...xs);
  const minY = Math.min(...ys);
  const maxX = Math.max(...xs) + 200; // Approximate node width
  const maxY = Math.max(...ys) + 100; // Approximate node height
  
  return {
    x: minX,
    y: minY,
    width: maxX - minX,
    height: maxY - minY
  };
}

/**
 * Generate a random position near a target point
 */
export function generateRandomPosition(targetX: number, targetY: number, spread: number = 150) {
  return {
    x: targetX + (Math.random() * 2 - 1) * spread,
    y: targetY + (Math.random() * 2 - 1) * spread
  };
}

/**
 * Calculate the center point between multiple nodes
 */
export function calculateCenter(nodes: Node[]) {
  if (nodes.length === 0) return { x: 0, y: 0 };
  
  const sum = nodes.reduce(
    (acc, node) => ({
      x: acc.x + node.position.x,
      y: acc.y + node.position.y
    }),
    { x: 0, y: 0 }
  );
  
  return {
    x: sum.x / nodes.length,
    y: sum.y / nodes.length
  };
}

/**
 * Auto-layout nodes in a mind map structure
 */
export function autoLayoutMindMap(centralNode: Node, relatedNodes: Node[]) {
  const center = centralNode.position;
  const nodeCount = relatedNodes.length;
  const radius = 300;
  
  return relatedNodes.map((node, index) => {
    const angle = (index / nodeCount) * Math.PI * 2;
    
    return {
      ...node,
      position: {
        x: center.x + Math.cos(angle) * radius,
        y: center.y + Math.sin(angle) * radius
      }
    };
  });
}
