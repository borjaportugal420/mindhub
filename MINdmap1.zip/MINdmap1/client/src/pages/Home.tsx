import React, { useState } from 'react';
import { Separator } from '@/components/ui/separator';
import MindMapFlow from '@/components/MindMapFlow.jsx';
import Header from '@/components/mindmap/Header';
import SimpleMindMap from '@/components/SimpleMindMap.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AreaChart, GitBranch } from 'lucide-react';

export default function Home() {
  const [activeTab, setActiveTab] = useState("flow");
  
  return (
    <div className="h-screen w-screen flex flex-col bg-slate-950 overflow-hidden">
      <Header />
      <Separator />
      
      <div className="px-4 pt-2 flex justify-center">
        <Tabs 
          defaultValue="flow" 
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-96"
        >
          <TabsList className="grid grid-cols-2 mb-2">
            <TabsTrigger value="flow" className="flex items-center gap-2">
              <AreaChart size={16} />
              Flow Diagram
            </TabsTrigger>
            <TabsTrigger value="mindmap" className="flex items-center gap-2">
              <GitBranch size={16} />
              Mind Map
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>
      
      <div className="flex-1 overflow-hidden relative">
        {activeTab === "flow" && <MindMapFlow />}
        {activeTab === "mindmap" && <SimpleMindMap />}
      </div>
    </div>
  );
}
