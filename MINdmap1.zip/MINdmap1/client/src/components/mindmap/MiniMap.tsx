import { useTheme } from '@/hooks/use-theme';

export default function MiniMap() {
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  
  return (
    <div className="minimap glassmorphism absolute left-4 bottom-4 w-48 h-32 rounded-lg shadow-lg overflow-hidden z-10">
      <div className="w-full h-full relative">
        {/* Miniature version of canvas content */}
        <div className="absolute inset-2">
          {/* Example minimap content */}
          <div className={`bg-primary-200 dark:bg-primary-700/40 w-6 h-4 absolute left-4 top-3 rounded-sm`}></div>
          <div className={`bg-secondary-200 dark:bg-secondary-700/40 w-8 h-5 absolute right-3 top-10 rounded-sm`}></div>
          <div className={`bg-accent-200 dark:bg-accent-700/40 w-10 h-6 absolute left-12 bottom-5 rounded-sm`}></div>
          {/* Lines connecting nodes */}
          <div className={`absolute left-8 top-5 w-24 h-px bg-primary-400 dark:bg-primary-500/60 transform rotate-12`}></div>
          <div className={`absolute left-16 top-16 w-12 h-px bg-primary-400 dark:bg-primary-500/60 transform -rotate-45`}></div>
        </div>
        {/* Viewport indicator */}
        <div className="minimap-viewport absolute w-24 h-16 border-2 border-primary-500 rounded-sm" style={{ left: '20%', top: '15%' }}></div>
      </div>
    </div>
  );
}
