import { MousePointer, Hand, Plus, Link2, Type, Group, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Separator } from '@/components/ui/separator';
import { useMindMapStore } from '@/store/mindMapStore';

export default function CanvasControls() {
  const { deleteSelectedNode, selectedNode } = useMindMapStore();
  
  return (
    <div className="glassmorphism-strong rounded-full shadow-lg flex items-center px-1 my-2">
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="m-1 text-primary-500 rounded-full hover:bg-primary-100 dark:hover:bg-primary-900/30">
              <MousePointer className="h-4 w-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent className="glassmorphism border-none">
            <p>Select tool</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="m-1 rounded-full hover:bg-primary-100 dark:hover:bg-primary-900/30">
              <Hand className="h-4 w-4 text-gray-500" />
            </Button>
          </TooltipTrigger>
          <TooltipContent className="glassmorphism border-none">
            <p>Hand tool</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      
      <Separator orientation="vertical" className="h-6 mx-1 bg-slate-300/50 dark:bg-slate-600/50" />
      
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="m-1 rounded-full hover:bg-primary-100 dark:hover:bg-primary-900/30">
              <Plus className="h-4 w-4 text-emerald-500" />
            </Button>
          </TooltipTrigger>
          <TooltipContent className="glassmorphism border-none">
            <p>Add node</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="m-1 rounded-full hover:bg-primary-100 dark:hover:bg-primary-900/30">
              <Link2 className="h-4 w-4 text-blue-500" />
            </Button>
          </TooltipTrigger>
          <TooltipContent className="glassmorphism border-none">
            <p>Connect nodes</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="m-1 rounded-full hover:bg-primary-100 dark:hover:bg-primary-900/30">
              <Type className="h-4 w-4 text-purple-500" />
            </Button>
          </TooltipTrigger>
          <TooltipContent className="glassmorphism border-none">
            <p>Text tool</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      
      <Separator orientation="vertical" className="h-6 mx-1 bg-slate-300/50 dark:bg-slate-600/50" />
      
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="m-1 rounded-full hover:bg-primary-100 dark:hover:bg-primary-900/30">
              <Group className="h-4 w-4 text-amber-500" />
            </Button>
          </TooltipTrigger>
          <TooltipContent className="glassmorphism border-none">
            <p>Group selection</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon" 
              className={`m-1 rounded-full ${selectedNode ? 'text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20' : 'text-slate-400'}`}
              onClick={() => deleteSelectedNode()}
              disabled={!selectedNode}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent className="glassmorphism border-none">
            <p>Delete</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  );
}
