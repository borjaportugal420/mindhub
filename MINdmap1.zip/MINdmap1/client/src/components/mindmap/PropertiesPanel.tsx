import React, { useState } from 'react';
import { 
  X, 
  ChevronLeft, 
  ChevronRight,
  Settings,
  Type,
  PaintBucket,
  Palette,
  Image,
  Link,
  AlignLeft,
  Sliders,
  Upload,
  FileText
} from 'lucide-react';
import { Node, Edge } from 'reactflow';
import { useMindMapStore } from '@/store/mindMapStore';
import { Separator } from '@/components/ui/separator';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface PropertiesPanelProps {
  isOpen: boolean;
  onToggle: () => void;
}

export default function PropertiesPanel({ isOpen, onToggle }: PropertiesPanelProps) {
  const [activeTab, setActiveTab] = useState('style');
  const { 
    selectedNode,
    selectedEdge, 
    updateNodeData,
    updateNodeStyle,
    updateEdgeStyle,
    changeNodeType
  } = useMindMapStore();

  // Handle node label change
  const handleLabelChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (selectedNode) {
      updateNodeData(selectedNode.id, { ...selectedNode.data, label: e.target.value });
    }
  };

  // Handle node type change
  const handleTypeChange = (value: string) => {
    if (selectedNode) {
      updateNodeData(selectedNode.id, { ...selectedNode.data, type: value });
    }
  };

  // Handle node background color change
  const handleColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (selectedNode) {
      updateNodeData(selectedNode.id, { ...selectedNode.data, color: e.target.value });
    }
  };

  // Handle node description change
  const handleDescriptionChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (selectedNode) {
      updateNodeData(selectedNode.id, { ...selectedNode.data, description: e.target.value });
    }
  };

  // Change node type (shape)
  const handleNodeTypeChange = (value: string) => {
    if (selectedNode) {
      changeNodeType(selectedNode.id, value);
    }
  };

  // Handle edge type change
  const handleEdgeTypeChange = (value: string) => {
    if (selectedEdge) {
      updateEdgeStyle(selectedEdge.id, { type: value });
    }
  };

  // Handle edge color change
  const handleEdgeColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (selectedEdge) {
      updateEdgeStyle(selectedEdge.id, { stroke: e.target.value });
    }
  };

  // Helper function to get node type name
  const getNodeTypeName = (type: string) => {
    switch (type) {
      case 'workflowNode': return 'Workflow Node';
      case 'basicNode': return 'Basic Node';
      case 'topicNode': return 'Topic Node';
      case 'ideaNode': return 'Idea Node';
      case 'taskNode': return 'Task Node';
      case 'noteNode': return 'Note Node';
      case 'subnodeNode': return 'Subnode';
      case 'subtopicNode': return 'Subtopic Node';
      case 'connectionNode': return 'Connection Node';
      case 'prdNode': return 'PRD Node';
      default: return 'Unknown Node';
    }
  };

  return (
    <div 
      className={`properties-panel fixed top-16 right-0 h-[calc(100vh-4rem)] z-10 bg-slate-900/90 backdrop-blur-md transition-all duration-500 ease-in-out border-l border-slate-700 shadow-xl flex flex-col ${
        isOpen ? 'translate-x-0 w-72 opacity-100' : 'translate-x-full w-0 opacity-0'
      }`}
      style={{
        boxShadow: isOpen ? '0 10px 25px -5px rgba(0, 0, 0, 0.3), 0 8px 10px -6px rgba(0, 0, 0, 0.2)' : 'none',
        borderLeft: isOpen ? '1px solid rgba(51, 65, 85, 0.7)' : 'none'
      }}
    >
      {/* Toggle button with enhanced animation */}
      <button
        onClick={onToggle}
        className="absolute -left-8 top-4 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-l-md p-1.5 text-slate-300 transition-all duration-300 ease-in-out hover:bg-indigo-600 hover:border-indigo-500"
        aria-label={isOpen ? 'Close properties panel' : 'Open properties panel'}
        style={{transform: isOpen ? 'scale(1.05)' : 'scale(1)'}}
      >
        <div className="transition-transform duration-300" style={{transform: isOpen ? 'rotate(0deg)' : 'rotate(180deg)'}}>
          <ChevronRight size={16} />
        </div>
      </button>
      
      {/* Header */}
      <div className="panel-header p-3 border-b border-slate-700 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-200 flex items-center">
          <Settings size={16} className="mr-2" />
          Properties
        </h3>
        <button
          onClick={onToggle}
          className="text-slate-400 hover:text-slate-200"
          aria-label="Close panel"
        >
          <X size={16} />
        </button>
      </div>
      
      {/* Panel content */}
      <div className="panel-content flex-1 overflow-y-auto">
        {selectedNode ? (
          <div className="p-3">
            <Badge className="mb-2">
              {getNodeTypeName(selectedNode.type as string)}
            </Badge>
            
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="style">Style</TabsTrigger>
                <TabsTrigger value="data">Data</TabsTrigger>
                <TabsTrigger value="advanced">Advanced</TabsTrigger>
              </TabsList>
              
              {/* Style tab - Enhanced with more options */}
              <TabsContent value="style" className="space-y-4 pt-3">
                <div className="space-y-2">
                  <Label htmlFor="node-type" className="flex items-center">
                    <Type size={14} className="mr-1.5 text-slate-400" />
                    Node Type
                  </Label>
                  <Select 
                    value={selectedNode.type as string} 
                    onValueChange={handleNodeTypeChange}
                  >
                    <SelectTrigger id="node-type" className="bg-slate-800/70 border-slate-700 text-sm">
                      <SelectValue placeholder="Select node type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="workflowNode">Workflow Node</SelectItem>
                      <SelectItem value="basicNode">Basic Node</SelectItem>
                      <SelectItem value="topicNode">Topic Node</SelectItem>
                      <SelectItem value="ideaNode">Idea Node</SelectItem>
                      <SelectItem value="taskNode">Task Node</SelectItem>
                      <SelectItem value="noteNode">Note Node</SelectItem>
                      <SelectItem value="subnodeNode">Subnode</SelectItem>
                      <SelectItem value="subtopicNode">Subtopic Node</SelectItem>
                      <SelectItem value="connectionNode">Connection Node</SelectItem>
                      <SelectItem value="prdNode">PRD Node</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="node-color" className="flex items-center">
                    <PaintBucket size={14} className="mr-1.5 text-slate-400" />
                    Header Color
                  </Label>
                  <div className="flex">
                    <Input 
                      id="node-color" 
                      type="color" 
                      value={selectedNode.data?.color || '#3182ce'} 
                      onChange={handleColorChange}
                      className="w-12 p-1 h-9 cursor-pointer"
                    />
                    <Input 
                      value={selectedNode.data?.color || '#3182ce'} 
                      onChange={handleColorChange}
                      className="flex-1 ml-2 bg-slate-800/70 border-slate-700 text-sm font-mono"
                    />
                  </div>
                  
                  {/* Color presets */}
                  <div className="mt-1 flex flex-wrap gap-1">
                    {['#3182ce', '#10b981', '#ef4444', '#f59e0b', '#8b5cf6', '#ec4899', '#6366f1', '#64748b'].map(color => (
                      <button
                        key={color}
                        className="w-6 h-6 rounded-full border border-slate-600 transition-transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-slate-400"
                        style={{ backgroundColor: color }}
                        onClick={() => handleColorChange({ target: { value: color } } as React.ChangeEvent<HTMLInputElement>)}
                        aria-label={`Set color to ${color}`}
                      />
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="node-badge-type" className="flex items-center">
                    <Palette size={14} className="mr-1.5 text-slate-400" />
                    Badge Type
                  </Label>
                  <Select 
                    value={selectedNode.data?.type || 'default'} 
                    onValueChange={handleTypeChange}
                  >
                    <SelectTrigger id="node-badge-type" className="bg-slate-800/70 border-slate-700 text-sm">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Trigger">Trigger</SelectItem>
                      <SelectItem value="Action">Action</SelectItem>
                      <SelectItem value="Processor">Processor</SelectItem>
                      <SelectItem value="Input">Input</SelectItem>
                      <SelectItem value="Output">Output</SelectItem>
                      <SelectItem value="default">Default</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {/* Background style options */}
                <div className="space-y-2">
                  <Label htmlFor="node-style" className="flex items-center">
                    <Sliders size={14} className="mr-1.5 text-slate-400" />
                    Visual Style
                  </Label>
                  <Select 
                    value={selectedNode.data?.style || 'default'} 
                    onValueChange={(value) => updateNodeData(selectedNode.id, { ...selectedNode.data, style: value })}
                  >
                    <SelectTrigger id="node-style" className="bg-slate-800/70 border-slate-700 text-sm">
                      <SelectValue placeholder="Select style" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="default">Default</SelectItem>
                      <SelectItem value="glass">Glassmorphic</SelectItem>
                      <SelectItem value="solid">Solid</SelectItem>
                      <SelectItem value="outline">Outline</SelectItem>
                      <SelectItem value="minimal">Minimal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {/* Border radius option */}
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="border-radius" className="flex items-center text-sm">Border Radius</Label>
                    <span className="text-xs text-slate-400">{selectedNode.data?.borderRadius || 8}px</span>
                  </div>
                  <input
                    id="border-radius"
                    type="range"
                    min="0"
                    max="24"
                    step="2"
                    value={selectedNode.data?.borderRadius || 8}
                    onChange={(e) => updateNodeData(selectedNode.id, { 
                      ...selectedNode.data, 
                      borderRadius: Number(e.target.value) 
                    })}
                    className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                  />
                </div>
              </TabsContent>
              
              {/* Data tab - Enhanced with more interactive features */}
              <TabsContent value="data" className="space-y-4 pt-3">
                <div className="space-y-2">
                  <Label htmlFor="node-label" className="flex items-center">
                    <AlignLeft size={14} className="mr-1.5 text-slate-400" />
                    Label
                  </Label>
                  <Input 
                    id="node-label" 
                    value={selectedNode.data?.label || ''} 
                    onChange={handleLabelChange}
                    className="bg-slate-800/70 border-slate-700 text-sm" 
                    placeholder="Enter node label"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="node-description" className="flex items-center">
                    <FileText size={14} className="mr-1.5 text-slate-400" />
                    Description
                  </Label>
                  <textarea 
                    id="node-description" 
                    value={selectedNode.data?.description || ''} 
                    onChange={handleDescriptionChange}
                    placeholder="Enter node description"
                    className="w-full h-20 px-3 py-2 text-sm rounded-md border border-slate-700 bg-slate-800/70 text-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2 focus:ring-offset-slate-900"
                  />
                </div>
                
                {selectedNode.type === 'workflowNode' && (
                  <>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <Label className="flex items-center">
                          <Link size={14} className="mr-1.5 text-slate-400" />
                          Inputs
                        </Label>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-7 text-xs"
                          onClick={() => {
                            const currentInputs = selectedNode.data?.inputs || [];
                            updateNodeData(selectedNode.id, {
                              ...selectedNode.data,
                              inputs: [...currentInputs, {
                                name: `Input ${currentInputs.length + 1}`,
                                id: `input-${Date.now()}`,
                                isArray: false
                              }]
                            });
                          }}
                        >
                          + Add Input
                        </Button>
                      </div>
                      <div className="bg-slate-800/70 rounded-md border border-slate-700 overflow-hidden">
                        {selectedNode.data?.inputs && selectedNode.data.inputs.length > 0 ? (
                          <div className="divide-y divide-slate-700">
                            {selectedNode.data.inputs.map((input: any, index: number) => (
                              <div key={index} className="flex items-center justify-between p-2 hover:bg-slate-700/50 group">
                                <div className="flex-1 min-w-0">
                                  <input
                                    value={input.name}
                                    onChange={(e) => {
                                      const newInputs = [...selectedNode.data.inputs];
                                      newInputs[index].name = e.target.value;
                                      updateNodeData(selectedNode.id, {
                                        ...selectedNode.data,
                                        inputs: newInputs
                                      });
                                    }}
                                    className="w-full bg-transparent border-none text-xs focus:outline-none focus:ring-0"
                                  />
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Badge variant={input.isArray ? "default" : "outline"} className="text-xs cursor-pointer"
                                    onClick={() => {
                                      const newInputs = [...selectedNode.data.inputs];
                                      newInputs[index].isArray = !newInputs[index].isArray;
                                      updateNodeData(selectedNode.id, {
                                        ...selectedNode.data,
                                        inputs: newInputs
                                      });
                                    }}
                                  >
                                    {input.isArray ? 'Array' : 'Value'}
                                  </Badge>
                                  <button 
                                    className="text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                    onClick={() => {
                                      const newInputs = [...selectedNode.data.inputs];
                                      newInputs.splice(index, 1);
                                      updateNodeData(selectedNode.id, {
                                        ...selectedNode.data,
                                        inputs: newInputs
                                      });
                                    }}
                                  >
                                    <X size={14} />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="text-xs text-slate-400 italic p-2">No inputs defined</p>
                        )}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <Label className="flex items-center">
                          <Link size={14} className="mr-1.5 text-slate-400" />
                          Outputs
                        </Label>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-7 text-xs"
                          onClick={() => {
                            const currentOutputs = selectedNode.data?.outputs || [];
                            updateNodeData(selectedNode.id, {
                              ...selectedNode.data,
                              outputs: [...currentOutputs, {
                                name: `Output ${currentOutputs.length + 1}`,
                                id: `output-${Date.now()}`,
                                isArray: false
                              }]
                            });
                          }}
                        >
                          + Add Output
                        </Button>
                      </div>
                      <div className="bg-slate-800/70 rounded-md border border-slate-700 overflow-hidden">
                        {selectedNode.data?.outputs && selectedNode.data.outputs.length > 0 ? (
                          <div className="divide-y divide-slate-700">
                            {selectedNode.data.outputs.map((output: any, index: number) => (
                              <div key={index} className="flex items-center justify-between p-2 hover:bg-slate-700/50 group">
                                <div className="flex-1 min-w-0">
                                  <input
                                    value={output.name}
                                    onChange={(e) => {
                                      const newOutputs = [...selectedNode.data.outputs];
                                      newOutputs[index].name = e.target.value;
                                      updateNodeData(selectedNode.id, {
                                        ...selectedNode.data,
                                        outputs: newOutputs
                                      });
                                    }}
                                    className="w-full bg-transparent border-none text-xs focus:outline-none focus:ring-0"
                                  />
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Badge variant={output.isArray ? "default" : "outline"} className="text-xs cursor-pointer"
                                    onClick={() => {
                                      const newOutputs = [...selectedNode.data.outputs];
                                      newOutputs[index].isArray = !newOutputs[index].isArray;
                                      updateNodeData(selectedNode.id, {
                                        ...selectedNode.data,
                                        outputs: newOutputs
                                      });
                                    }}
                                  >
                                    {output.isArray ? 'Array' : 'Value'}
                                  </Badge>
                                  <button 
                                    className="text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                    onClick={() => {
                                      const newOutputs = [...selectedNode.data.outputs];
                                      newOutputs.splice(index, 1);
                                      updateNodeData(selectedNode.id, {
                                        ...selectedNode.data,
                                        outputs: newOutputs
                                      });
                                    }}
                                  >
                                    <X size={14} />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="text-xs text-slate-400 italic p-2">No outputs defined</p>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </TabsContent>
              
              {/* Advanced tab - Enhanced with additional options */}
              <TabsContent value="advanced" className="space-y-4 pt-3">
                <div className="space-y-2">
                  <Label className="flex items-center text-xs text-slate-400 font-semibold">
                    NODE DETAILS
                  </Label>
                  
                  <div className="space-y-2">
                    <Label htmlFor="node-id" className="text-xs flex items-center">
                      <span className="text-slate-400">ID</span>
                    </Label>
                    <div className="flex">
                      <Input 
                        id="node-id"
                        value={selectedNode.id} 
                        disabled 
                        className="flex-1 bg-slate-800/70 text-slate-400 font-mono text-xs border-slate-700"
                      />
                      <Button
                        variant="outline" 
                        size="sm" 
                        className="ml-2 h-9 border-slate-700 hover:bg-slate-700"
                        onClick={() => {
                          navigator.clipboard.writeText(selectedNode.id);
                          // Could add a toast notification here
                        }}
                      >
                        Copy
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-xs flex items-center">
                      <span className="text-slate-400">Position</span>
                    </Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <div className="flex items-center mb-1">
                          <span className="text-xs text-slate-400 mr-1">X</span>
                          <input
                            type="range"
                            min={Math.round(selectedNode.position.x) - 100}
                            max={Math.round(selectedNode.position.x) + 100}
                            value={Math.round(selectedNode.position.x)}
                            onChange={(e) => {
                              const x = Number(e.target.value);
                              updateNodeData(selectedNode.id, {
                                ...selectedNode.data,
                                position: { x, y: selectedNode.position.y }
                              });
                            }}
                            className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                          />
                        </div>
                        <Input 
                          id="pos-x" 
                          value={Math.round(selectedNode.position.x)} 
                          onChange={(e) => {
                            const x = Number(e.target.value) || 0;
                            updateNodeData(selectedNode.id, {
                              ...selectedNode.data,
                              position: { x, y: selectedNode.position.y }
                            });
                          }}
                          className="bg-slate-800/70 text-slate-300 border-slate-700 text-xs"
                        />
                      </div>
                      <div>
                        <div className="flex items-center mb-1">
                          <span className="text-xs text-slate-400 mr-1">Y</span>
                          <input
                            type="range"
                            min={Math.round(selectedNode.position.y) - 100}
                            max={Math.round(selectedNode.position.y) + 100}
                            value={Math.round(selectedNode.position.y)}
                            onChange={(e) => {
                              const y = Number(e.target.value);
                              updateNodeData(selectedNode.id, {
                                ...selectedNode.data,
                                position: { x: selectedNode.position.x, y }
                              });
                            }}
                            className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                          />
                        </div>
                        <Input 
                          id="pos-y" 
                          value={Math.round(selectedNode.position.y)} 
                          onChange={(e) => {
                            const y = Number(e.target.value) || 0;
                            updateNodeData(selectedNode.id, {
                              ...selectedNode.data,
                              position: { x: selectedNode.position.x, y }
                            });
                          }}
                          className="bg-slate-800/70 text-slate-300 border-slate-700 text-xs"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2 mt-3">
                    <Label className="text-xs flex items-center">
                      <span className="text-slate-400">Dimensions</span>
                    </Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label htmlFor="width" className="text-xs">Width</Label>
                        <Input 
                          id="width" 
                          value={selectedNode.data?.width || 'auto'} 
                          onChange={(e) => updateNodeData(selectedNode.id, { 
                            ...selectedNode.data, 
                            width: e.target.value
                          })}
                          className="bg-slate-800/70 text-slate-300 border-slate-700 text-xs"
                          placeholder="auto"
                        />
                      </div>
                      <div>
                        <Label htmlFor="height" className="text-xs">Height</Label>
                        <Input 
                          id="height" 
                          value={selectedNode.data?.height || 'auto'} 
                          onChange={(e) => updateNodeData(selectedNode.id, { 
                            ...selectedNode.data, 
                            height: e.target.value
                          })}
                          className="bg-slate-800/70 text-slate-300 border-slate-700 text-xs"
                          placeholder="auto"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                
                <Separator className="my-3" />
                
                <div className="space-y-2">
                  <Label className="flex items-center text-xs text-slate-400 font-semibold">
                    ADVANCED OPTIONS
                  </Label>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="zindex" className="text-xs">Z-Index</Label>
                      <span className="text-xs text-slate-400">{selectedNode.data?.zIndex || 0}</span>
                    </div>
                    <input
                      id="zindex"
                      type="range"
                      min="0"
                      max="10"
                      step="1"
                      value={selectedNode.data?.zIndex || 0}
                      onChange={(e) => updateNodeData(selectedNode.id, { 
                        ...selectedNode.data, 
                        zIndex: Number(e.target.value) 
                      })}
                      className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                    />
                  </div>
                  
                  <div className="space-y-1 mt-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="locked" className="text-xs flex items-center">
                        Lock Position
                      </Label>
                      <button 
                        onClick={() => updateNodeData(selectedNode.id, { 
                          ...selectedNode.data, 
                          locked: !selectedNode.data?.locked 
                        })}
                        className={`relative inline-flex h-4 w-8 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out ${
                          selectedNode.data?.locked ? 'bg-indigo-500' : 'bg-slate-700'
                        }`}
                      >
                        <span 
                          className={`pointer-events-none inline-block h-3 w-3 transform rounded-full bg-white shadow-lg transition duration-200 ease-in-out ${
                            selectedNode.data?.locked ? 'translate-x-4' : 'translate-x-0'
                          }`} 
                        />
                      </button>
                    </div>
                  </div>
                  
                  <div className="space-y-1 mt-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="selectable" className="text-xs flex items-center">
                        Selectable
                      </Label>
                      <button 
                        onClick={() => updateNodeData(selectedNode.id, { 
                          ...selectedNode.data, 
                          selectable: selectedNode.data?.selectable === false ? true : false 
                        })}
                        className={`relative inline-flex h-4 w-8 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out ${
                          selectedNode.data?.selectable !== false ? 'bg-indigo-500' : 'bg-slate-700'
                        }`}
                      >
                        <span 
                          className={`pointer-events-none inline-block h-3 w-3 transform rounded-full bg-white shadow-lg transition duration-200 ease-in-out ${
                            selectedNode.data?.selectable !== false ? 'translate-x-4' : 'translate-x-0'
                          }`} 
                        />
                      </button>
                    </div>
                  </div>
                </div>
                
                <Separator className="my-3" />
                
                <div className="space-y-1">
                  <Label className="flex items-center text-xs text-slate-400 font-semibold">
                    ACTIONS
                  </Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex items-center justify-center text-xs border-slate-700 hover:bg-indigo-500 hover:text-white hover:border-indigo-500 transition-colors"
                    >
                      <Upload size={12} className="mr-1" />
                      Add Image
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex items-center justify-center text-xs border-slate-700 hover:bg-indigo-500 hover:text-white hover:border-indigo-500 transition-colors"
                    >
                      <FileText size={12} className="mr-1" />
                      Add File
                    </Button>
                  </div>
                  <div className="mt-2">
                    <Button 
                      variant="destructive" 
                      size="sm" 
                      className="w-full text-xs bg-red-900/40 hover:bg-red-900/60 text-red-300"
                      onClick={() => {
                        if (window.confirm('Are you sure you want to delete this node?')) {
                          // Delete node action
                        }
                      }}
                    >
                      Delete Node
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        ) : selectedEdge ? (
          <div className="p-3 space-y-4">
            <Badge className="mb-2">Edge Properties</Badge>
            
            <div className="space-y-2">
              <Label htmlFor="edge-type">Edge Type</Label>
              <Select 
                value={selectedEdge.type || 'default'} 
                onValueChange={handleEdgeTypeChange}
              >
                <SelectTrigger id="edge-type">
                  <SelectValue placeholder="Select edge type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="default">Default</SelectItem>
                  <SelectItem value="flowEdge">Flow Edge</SelectItem>
                  <SelectItem value="step">Step</SelectItem>
                  <SelectItem value="smoothstep">Smooth Step</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="edge-color">Edge Color</Label>
              <div className="flex">
                <Input 
                  id="edge-color" 
                  type="color" 
                  value={selectedEdge.style?.stroke || '#64748b'} 
                  onChange={handleEdgeColorChange}
                  className="w-12 p-1 h-9"
                />
                <Input 
                  value={selectedEdge.style?.stroke || '#64748b'} 
                  onChange={handleEdgeColorChange}
                  className="flex-1 ml-2"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Edge ID</Label>
              <div className="flex">
                <Input 
                  value={selectedEdge.id} 
                  disabled 
                  className="flex-1 bg-slate-800 text-slate-400 font-mono text-xs"
                />
                <Button
                  variant="outline" 
                  size="sm" 
                  className="ml-2 h-9"
                  onClick={() => navigator.clipboard.writeText(selectedEdge.id)}
                >
                  Copy
                </Button>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Connection</Label>
              <div className="bg-slate-800 rounded-md p-2 border border-slate-700">
                <div className="grid grid-cols-2 gap-1 text-xs">
                  <div className="space-y-1">
                    <p className="text-slate-400">From</p>
                    <p>{selectedEdge.source}</p>
                    <p className="text-slate-400 mt-1">Handle</p>
                    <p>{selectedEdge.sourceHandle || 'default'}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-slate-400">To</p>
                    <p>{selectedEdge.target}</p>
                    <p className="text-slate-400 mt-1">Handle</p>
                    <p>{selectedEdge.targetHandle || 'default'}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full p-6 text-center">
            <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mb-4">
              <Sliders size={24} className="text-slate-400" />
            </div>
            <h3 className="text-slate-300 font-medium mb-2">No Element Selected</h3>
            <p className="text-slate-400 text-sm">
              Select a node or edge to view and edit its properties
            </p>
          </div>
        )}
      </div>
      
      {/* Footer */}
      {(selectedNode || selectedEdge) && (
        <div className="panel-footer p-3 border-t border-slate-700">
          <Button variant="outline" size="sm" className="w-full" onClick={onToggle}>
            Close Panel
          </Button>
        </div>
      )}
    </div>
  );
}
