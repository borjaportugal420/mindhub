import React from 'react';
import { useTheme } from '@/components/ThemeProvider';
import ThemeToggle from '@/components/ThemeToggle';
import { Button } from '@/components/ui/button';
import { Save, FileText, Share2, Download, Settings, HelpCircle } from 'lucide-react';
import { useMindMapStore } from '@/store/mindMapStore';
import { exportToJson } from '@/lib/mindMapUtils';

export default function Header() {
  const { theme } = useTheme();
  const { nodes, edges } = useMindMapStore();
  
  // Export the current mind map
  const handleExport = () => {
    if (nodes.length === 0) return;
    
    const dataStr = JSON.stringify(exportToJson(nodes, edges), null, 2);
    const dataUri = `data:application/json;charset=utf-8,${encodeURIComponent(dataStr)}`;
    
    const exportFileName = 'mindmap-export.json';
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileName);
    linkElement.click();
  };
  
  return (
    <header className="w-full h-16 border-b border-slate-800 bg-slate-900/80 backdrop-blur-sm flex items-center justify-between px-4">
      {/* Left side - Logo and title */}
      <div className="flex items-center">
        <div className="flex items-center mr-8">
          <div className="w-8 h-8 rounded-md bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white font-bold text-xl mr-2">
            F
          </div>
          <h1 className="text-slate-100 font-semibold tracking-tight">FlowHive</h1>
        </div>
        
        <div className="flex space-x-1">
          <Button variant="ghost" size="sm" className="text-xs">
            <FileText size={14} className="mr-1" />
            File
          </Button>
          <Button variant="ghost" size="sm" className="text-xs">
            <Settings size={14} className="mr-1" />
            Edit
          </Button>
          <Button variant="ghost" size="sm" className="text-xs">
            <HelpCircle size={14} className="mr-1" />
            Help
          </Button>
        </div>
      </div>
      
      {/* Right side - Actions */}
      <div className="flex items-center space-x-2">
        <Button
          variant="outline"
          size="sm"
          className="text-xs"
        >
          <Save size={14} className="mr-1" />
          Save
        </Button>
        
        <Button
          variant="outline"
          size="sm"
          className="text-xs"
          onClick={handleExport}
        >
          <Download size={14} className="mr-1" />
          Export
        </Button>
        
        <Button
          variant="outline"
          size="sm"
          className="text-xs"
        >
          <Share2 size={14} className="mr-1" />
          Share
        </Button>
        
        <div className="ml-2">
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}
