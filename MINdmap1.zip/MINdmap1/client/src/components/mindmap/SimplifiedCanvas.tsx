import React, { useCallback, useRef, useState } from 'react';
import ReactFlow, {
  MiniMap,
  Controls,
  Background,
  BackgroundVariant,
  useNodesState,
  useEdgesState,
  addEdge,
  Edge,
  Connection,
  Node,
  Panel,
  MarkerType,
  ConnectionLineType
} from 'reactflow';
import 'reactflow/dist/style.css';
import BrainNode from './BrainNode';
import { Button } from '@/components/ui/button';
import { PlusCircle, MinusCircle, Edit, Text } from 'lucide-react';

// Define custom node types
const nodeTypes = {
  brainNode: BrainNode,
};

// Create an initial brain node
const initialNodes: Node[] = [
  {
    id: 'brain-1',
    type: 'brainNode',
    position: { x: 250, y: 150 },
    data: { 
      label: 'Brain Node',
      text: 'Click to edit this text'
    }
  }
];

// No initial edges
const initialEdges: Edge[] = [];

export default function SimplifiedCanvas() {
  // State for nodes and edges
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [editingText, setEditingText] = useState(false);
  const [nodeText, setNodeText] = useState('');

  // Custom edge rendering to make direct connections
  const edgeOptions = {
    style: { strokeWidth: 2, stroke: '#ff0072' },
    type: 'simplebezier', // Use a simple bezier curve with less curvature
    markerEnd: {
      type: MarkerType.ArrowClosed,
      color: '#ff0072',
    },
  };

  // Handle new connections
  const onConnect = useCallback(
    (params: Connection) => {
      // Create a straight connection between nodes
      const newEdge = {
        ...params,
        id: `e-${params.source}-${params.target}`,
        type: 'simplebezier',
        animated: true,
        style: { stroke: '#ff0072', strokeWidth: 2 },
        markerEnd: {
          type: MarkerType.ArrowClosed,
          color: '#ff0072',
        },
      };
      setEdges((eds) => addEdge(newEdge, eds));
    },
    [setEdges]
  );

  // Handle node selection
  const onNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    setSelectedNode(node);
    setNodeText(node.data.text || '');
  }, []);

  // Add a new brain node
  const addBrainNode = useCallback(() => {
    const id = `brain-${nodes.length + 1}`;
    const newNode = {
      id,
      type: 'brainNode',
      position: {
        x: Math.random() * 500,
        y: Math.random() * 300,
      },
      data: {
        label: `Brain ${nodes.length + 1}`,
        text: 'New brain node'
      },
    };
    setNodes((nds) => [...nds, newNode]);
  }, [nodes.length, setNodes]);

  // Edit node text
  const startEditingText = () => {
    if (selectedNode) {
      setEditingText(true);
    }
  };

  // Save edited text
  const saveNodeText = () => {
    if (selectedNode) {
      setNodes(
        nodes.map((node) => {
          if (node.id === selectedNode.id) {
            return {
              ...node,
              data: {
                ...node.data,
                text: nodeText,
              },
            };
          }
          return node;
        })
      );
      setEditingText(false);
    }
  };

  return (
    <div className="w-full h-full">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onNodeClick={onNodeClick}
        nodeTypes={nodeTypes}
        defaultEdgeOptions={edgeOptions}
        connectionLineType={ConnectionLineType.SmoothStep}
        fitView
        proOptions={{ hideAttribution: true }}
      >
        {/* Premium background styling */}
        <Background
          gap={20}
          color="#334155"
          variant={BackgroundVariant.Dots}
          size={1}
          style={{
            opacity: 0.3,
            backgroundColor: '#0f172a',
            backgroundImage:
              'radial-gradient(circle at 15% 50%, rgba(30, 64, 175, 0.03) 0%, transparent 25%), radial-gradient(circle at 85% 30%, rgba(124, 58, 237, 0.03) 0%, transparent 30%)',
          }}
        />
        
        <Controls />
        <MiniMap nodeStrokeWidth={3} zoomable pannable />
        
        {/* Toolbar */}
        <Panel position="top-center" className="flex gap-2 bg-slate-800/80 p-2 rounded-md backdrop-blur-sm">
          <Button size="sm" variant="outline" onClick={addBrainNode} title="Add Brain Node">
            <PlusCircle size={16} className="mr-1" /> Add Brain
          </Button>
          {selectedNode && (
            <>
              <Button size="sm" variant="outline" onClick={startEditingText} title="Edit Text">
                <Edit size={16} className="mr-1" /> Edit Text
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => setNodes(nodes.filter(n => n.id !== selectedNode.id))}
                title="Delete Node"
              >
                <MinusCircle size={16} className="mr-1" /> Delete
              </Button>
            </>
          )}
        </Panel>
        
        {/* Text editing panel */}
        {editingText && selectedNode && (
          <Panel position="bottom-center" className="bg-slate-800/90 p-3 rounded-md backdrop-blur-sm max-w-md">
            <div className="flex flex-col gap-2">
              <label className="flex items-center text-white">
                <Text size={16} className="mr-1" /> Node Text:
              </label>
              <textarea
                className="bg-slate-900 text-white p-2 rounded border border-slate-700 w-full"
                value={nodeText}
                onChange={(e) => setNodeText(e.target.value)}
                rows={4}
              />
              <div className="flex justify-end gap-2 mt-1">
                <Button size="sm" variant="outline" onClick={() => setEditingText(false)}>
                  Cancel
                </Button>
                <Button size="sm" onClick={saveNodeText}>
                  Save
                </Button>
              </div>
            </div>
          </Panel>
        )}
      </ReactFlow>
    </div>
  );
}