import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Folder, Box, Layout, FileText, FileCode, PenTool, Lightbulb, CheckSquare, Workflow, Cpu, Database, Code, Info } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';

interface LeftSidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

export default function LeftSidebar({ isOpen, onToggle }: LeftSidebarProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('nodes');
  
  // Define the item type with proper TypeScript interface
  interface CategoryItem {
    id: string;
    name: string;
    type: string;
    color: string;
    icon: React.ReactNode;
    badge?: string;
  }
  
  // Node categories
  const categories = [
    {
      id: 'workflow',
      name: 'Workflow',
      icon: <Workflow size={16} />,
      items: [
        { id: 'trigger', name: 'Trigger', type: 'workflowNode', color: '#9333ea', icon: <Box size={14} />, badge: 'Trigger' },
        { id: 'action', name: 'Action', type: 'workflowNode', color: '#3b82f6', icon: <Cpu size={14} />, badge: 'Action' },
        { id: 'processor', name: 'Processor', type: 'workflowNode', color: '#10b981', icon: <Code size={14} />, badge: 'Processor' },
        { id: 'input', name: 'Input', type: 'workflowNode', color: '#f59e0b', icon: <Layout size={14} />, badge: 'Input' },
        { id: 'output', name: 'Output', type: 'workflowNode', color: '#ef4444', icon: <Database size={14} />, badge: 'Output' },
      ] as CategoryItem[]
    },
    {
      id: 'mindmap',
      name: 'Mind Map',
      icon: <Lightbulb size={16} />,
      items: [
        { id: 'topic', name: 'Topic', type: 'topicNode', color: '#3b82f6', icon: <FileText size={14} /> },
        { id: 'subtopic', name: 'Subtopic', type: 'subtopicNode', color: '#60a5fa', icon: <FileText size={14} /> },
        { id: 'idea', name: 'Idea', type: 'ideaNode', color: '#f59e0b', icon: <Lightbulb size={14} /> },
        { id: 'task', name: 'Task', type: 'taskNode', color: '#10b981', icon: <CheckSquare size={14} /> },
        { id: 'note', name: 'Note', type: 'noteNode', color: '#94a3b8', icon: <PenTool size={14} /> },
      ] as CategoryItem[]
    },
    {
      id: 'connections',
      name: 'Connections',
      icon: <Info size={16} />,
      items: [
        { id: 'connection', name: 'Connection', type: 'connectionNode', color: '#6366f1', icon: <Info size={14} /> },
      ] as CategoryItem[]
    },
  ];
  
  // Search filter
  const filteredCategories = categories.map(category => ({
    ...category,
    items: category.items.filter(item => 
      item.name.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })).filter(category => category.items.length > 0);
  
  // Handle drag start to enable node creation by dragging
  const onDragStart = (event: React.DragEvent, nodeType: string, data: any = {}) => {
    event.dataTransfer.setData('application/reactflow/type', nodeType);
    event.dataTransfer.setData('application/reactflow/data', JSON.stringify(data));
    event.dataTransfer.effectAllowed = 'move';
  };

  return (
    <div
      className={`left-sidebar fixed top-16 left-0 h-[calc(100vh-4rem)] z-10 bg-slate-900/90 backdrop-blur-md transition-all duration-500 ease-in-out border-r border-slate-700 shadow-xl flex flex-col ${
        isOpen ? 'translate-x-0 w-60 opacity-100' : '-translate-x-full w-0 opacity-0'
      }`}
      style={{
        boxShadow: isOpen ? '0 10px 25px -5px rgba(0, 0, 0, 0.3), 0 8px 10px -6px rgba(0, 0, 0, 0.2)' : 'none',
        borderRight: isOpen ? '1px solid rgba(51, 65, 85, 0.7)' : 'none'
      }}
    >
      {/* Toggle button with enhanced animation */}
      <button
        onClick={onToggle}
        className="absolute -right-8 top-4 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-r-md p-1.5 text-slate-300 transition-all duration-300 ease-in-out hover:bg-indigo-600 hover:border-indigo-500"
        aria-label={isOpen ? 'Close sidebar' : 'Open sidebar'}
        style={{transform: isOpen ? 'scale(1.05)' : 'scale(1)'}}
      >
        <div className="transition-transform duration-300" style={{transform: isOpen ? 'rotate(0deg)' : 'rotate(180deg)'}}>
          <ChevronLeft size={16} />
        </div>
      </button>
      
      {/* Header */}
      <div className="p-3 border-b border-slate-700">
        <h3 className="text-sm font-semibold text-slate-200 flex items-center">
          <Folder size={16} className="mr-2" />
          Node Library
        </h3>
        <div className="mt-2">
          <Input
            placeholder="Search nodes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="h-8 text-xs bg-slate-800 border-slate-700"
          />
        </div>
      </div>
      
      {/* Content */}
      <div className="flex-1 overflow-hidden">
        <Tabs defaultValue="nodes" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full">
            <TabsTrigger value="nodes" className="flex-1 text-xs">Nodes</TabsTrigger>
            <TabsTrigger value="templates" className="flex-1 text-xs">Templates</TabsTrigger>
          </TabsList>
          
          <TabsContent value="nodes" className="flex-1 overflow-hidden">
            <ScrollArea className="h-[calc(100vh-11rem)]">
              <div className="p-3">
                {searchTerm && (
                  <p className="text-xs text-slate-400 mb-2">
                    {filteredCategories.reduce((acc, cat) => acc + cat.items.length, 0)} results
                  </p>
                )}
                
                <Accordion type="multiple" defaultValue={['workflow', 'mindmap']} className="space-y-2">
                  {filteredCategories.map((category) => (
                    <AccordionItem key={category.id} value={category.id} className="border-slate-700">
                      <AccordionTrigger className="text-xs font-medium py-1.5 hover:bg-slate-800 rounded px-2">
                        <div className="flex items-center">
                          <span className="mr-2 text-slate-400">{category.icon}</span>
                          {category.name}
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="pl-2 grid grid-cols-1 gap-1 mt-1">
                          {category.items.map((item) => {
                            // Create different data based on node type
                            let nodeData: any = { label: item.name, color: item.color };
                            
                            if (item.type === 'workflowNode') {
                              const castedItem = item as CategoryItem;
                              nodeData = {
                                ...nodeData,
                                type: castedItem.badge || 'Default',
                                inputs: [
                                  { 
                                    name: 'Input 1', 
                                    id: 'input1',
                                    properties: [
                                      { name: 'Format', id: 'format' },
                                      { name: 'Auth', id: 'auth' }
                                    ],
                                    isArray: true
                                  },
                                  { name: 'Input 2', id: 'input2' }
                                ],
                                outputs: [
                                  { 
                                    name: 'Output 1', 
                                    id: 'output1',
                                    properties: [
                                      { name: 'Data', id: 'data' },
                                      { name: 'Format', id: 'format' }
                                    ],
                                    isArray: true 
                                  },
                                  { name: 'Output 2', id: 'output2' }
                                ]
                              };
                            }
                            
                            return (
                              <div
                                key={item.id}
                                className="node-item flex items-center p-1.5 rounded hover:bg-slate-800 cursor-grab text-xs"
                                draggable
                                onDragStart={(event) => onDragStart(event, item.type, nodeData)}
                              >
                                <div 
                                  className="w-5 h-5 rounded flex items-center justify-center mr-2"
                                  style={{ backgroundColor: item.color }}
                                >
                                  {item.icon}
                                </div>
                                <span>{item.name}</span>
                              </div>
                            );
                          })}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="templates" className="flex-1 overflow-hidden">
            <ScrollArea className="h-[calc(100vh-11rem)]">
              <div className="p-3 space-y-3">
                <p className="text-xs text-slate-400">
                  Templates allow you to quickly create complex diagrams
                </p>
                
                {/* Template items */}
                <div className="space-y-2">
                  <div className="template-item border border-slate-700 rounded-md p-2 hover:bg-slate-800 cursor-pointer">
                    <h4 className="text-xs font-medium">Basic Workflow</h4>
                    <p className="text-xs text-slate-400 mt-1">A simple workflow with trigger, action and output nodes</p>
                  </div>
                  
                  <div className="template-item border border-slate-700 rounded-md p-2 hover:bg-slate-800 cursor-pointer">
                    <h4 className="text-xs font-medium">Mind Map Structure</h4>
                    <p className="text-xs text-slate-400 mt-1">Central topic with radiating subtopics and ideas</p>
                  </div>
                  
                  <div className="template-item border border-slate-700 rounded-md p-2 hover:bg-slate-800 cursor-pointer">
                    <h4 className="text-xs font-medium">Data Processing Flow</h4>
                    <p className="text-xs text-slate-400 mt-1">Input → Process → Transform → Output structure</p>
                  </div>
                </div>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Footer */}
      <div className="p-3 border-t border-slate-700">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span>Drag & drop to add nodes</span>
        </div>
      </div>
    </div>
  );
}
