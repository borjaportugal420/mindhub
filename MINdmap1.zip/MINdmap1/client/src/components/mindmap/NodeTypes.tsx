import React, { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { useMindMapStore } from '@/store/mindMapStore';
import { ChevronDown, ChevronRight, Settings, X, Copy, Edit, Trash2 } from 'lucide-react';
import WorkflowNode from './WorkflowNode';

// Basic node component for simple nodes
export const BasicNode = memo(({ data, selected }: NodeProps) => {
  return (
    <div className={`p-3 rounded-md shadow-md ${selected ? 'ring-2 ring-blue-500' : ''}`}
         style={{ backgroundColor: data.color || '#3182ce', color: 'white' }}>
      <Handle type="target" position={Position.Top} className="w-3 h-3 !border-2 !bg-white" />
      <div className="text-sm font-medium">{data.label}</div>
      {data.content && <div className="text-xs mt-1">{data.content}</div>}
      <Handle type="source" position={Position.Bottom} className="w-3 h-3 !border-2 !bg-white" />
    </div>
  );
});

// Topic node for mind maps
export const TopicNode = memo(({ data, selected }: NodeProps) => {
  return (
    <div className={`px-4 py-2 rounded-lg shadow-md ${selected ? 'ring-2 ring-blue-500' : ''}`}
         style={{ backgroundColor: data.color || '#3b82f6', color: 'white', minWidth: '140px' }}>
      <Handle type="target" position={Position.Top} className="w-3 h-3 !border-2 !bg-white" />
      <div className="text-sm font-medium text-center">{data.label}</div>
      <Handle type="source" position={Position.Bottom} className="w-3 h-3 !border-2 !bg-white" />
      <Handle type="source" position={Position.Right} className="w-3 h-3 !border-2 !bg-white" />
      <Handle type="source" position={Position.Left} className="w-3 h-3 !border-2 !bg-white" />
    </div>
  );
});

// Subtopic node for mind maps
export const SubtopicNode = memo(({ data, selected }: NodeProps) => {
  return (
    <div className={`px-3 py-1.5 rounded-md shadow-md ${selected ? 'ring-2 ring-blue-500' : ''}`}
         style={{ backgroundColor: data.color || '#60a5fa', color: 'white', minWidth: '120px' }}>
      <Handle type="target" position={Position.Top} className="w-2.5 h-2.5 !border-2 !bg-white" />
      <div className="text-xs font-medium text-center">{data.label}</div>
      <Handle type="source" position={Position.Bottom} className="w-2.5 h-2.5 !border-2 !bg-white" />
      <Handle type="source" position={Position.Right} className="w-2.5 h-2.5 !border-2 !bg-white" />
      <Handle type="source" position={Position.Left} className="w-2.5 h-2.5 !border-2 !bg-white" />
    </div>
  );
});

// Subnode for deeply nested structures
export const SubnodeNode = memo(({ data, selected }: NodeProps) => {
  return (
    <div className={`px-2 py-1 rounded shadow-md ${selected ? 'ring-2 ring-blue-500' : ''}`}
         style={{ backgroundColor: data.color || '#93c5fd', color: 'white', minWidth: '100px' }}>
      <Handle type="target" position={Position.Top} className="w-2 h-2 !border !bg-white" />
      <div className="text-xs text-center">{data.label}</div>
      <Handle type="source" position={Position.Bottom} className="w-2 h-2 !border !bg-white" />
      <Handle type="source" position={Position.Right} className="w-2 h-2 !border !bg-white" />
      <Handle type="source" position={Position.Left} className="w-2 h-2 !border !bg-white" />
    </div>
  );
});

// Idea node
export const IdeaNode = memo(({ data, selected }: NodeProps) => {
  return (
    <div className={`px-3 py-2 rounded-full shadow-md ${selected ? 'ring-2 ring-yellow-500' : ''}`}
         style={{ backgroundColor: data.color || '#f59e0b', color: 'white', minWidth: '100px' }}>
      <Handle type="target" position={Position.Top} className="w-3 h-3 !border-2 !bg-white" />
      <div className="text-xs font-medium text-center">{data.label}</div>
      {data.content && <div className="text-xs mt-1 text-center">{data.content}</div>}
      <Handle type="source" position={Position.Bottom} className="w-3 h-3 !border-2 !bg-white" />
    </div>
  );
});

// Task node
export const TaskNode = memo(({ data, selected }: NodeProps) => {
  return (
    <div className={`px-3 py-2 rounded-md shadow-md ${selected ? 'ring-2 ring-green-500' : ''}`}
         style={{ 
           backgroundColor: data.color || '#10b981', 
           color: 'white', 
           minWidth: '140px',
           borderLeft: '4px solid rgba(255, 255, 255, 0.5)'
         }}>
      <Handle type="target" position={Position.Top} className="w-3 h-3 !border-2 !bg-white" />
      <div className="text-xs font-medium">{data.label}</div>
      {data.content && <div className="text-xs mt-1">{data.content}</div>}
      <Handle type="source" position={Position.Bottom} className="w-3 h-3 !border-2 !bg-white" />
    </div>
  );
});

// Note node for text content
export const NoteNode = memo(({ data, selected }: NodeProps) => {
  return (
    <div className={`p-3 rounded-md shadow-md border-l-4 ${selected ? 'ring-2 ring-slate-500' : ''}`}
         style={{ 
           backgroundColor: data.color || '#334155', 
           borderLeftColor: '#94a3b8',
           color: 'white', 
           minWidth: '160px',
           maxWidth: '240px'
         }}>
      <Handle type="target" position={Position.Top} className="w-3 h-3 !border-2 !bg-white opacity-50" />
      {data.label && <div className="text-xs font-medium mb-1">{data.label}</div>}
      <div className="text-xs whitespace-pre-wrap">{data.content}</div>
    </div>
  );
});

// PRD node for product requirements
export const PrdNode = memo(({ data, selected }: NodeProps) => {
  return (
    <div className={`p-3 rounded-md shadow-md ${selected ? 'ring-2 ring-purple-500' : ''}`}
         style={{ 
           backgroundColor: data.color || '#8b5cf6', 
           color: 'white', 
           minWidth: '180px',
           maxWidth: '280px'
         }}>
      <Handle type="target" position={Position.Top} className="w-3 h-3 !border-2 !bg-white" />
      <div className="text-sm font-medium mb-1">{data.label}</div>
      <div className="text-xs bg-purple-900/50 p-2 rounded">
        {data.content || 'Add product requirements here'}
      </div>
      <Handle type="source" position={Position.Bottom} className="w-3 h-3 !border-2 !bg-white" />
    </div>
  );
});

// Connection node for displaying connection info
export const ConnectionNode = memo(({ data, selected }: NodeProps) => {
  return (
    <div className={`px-3 py-1.5 rounded-md shadow-md border ${selected ? 'ring-2 ring-indigo-500' : ''}`}
         style={{ 
           backgroundColor: 'rgba(99, 102, 241, 0.2)', 
           borderColor: '#6366f1',
           backdropFilter: 'blur(8px)',
           color: 'white', 
           minWidth: '120px'
         }}>
      <div className="text-xs font-medium">{data.label}</div>
      {data.description && <div className="text-xs mt-1 text-indigo-200">{data.description}</div>}
    </div>
  );
});

// Exporting the workflow node as a named export
export { WorkflowNode };
