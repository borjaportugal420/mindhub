import React, { useState, useCallback, useRef } from 'react';
import ReactFlow, {
  ReactFlowProvider,
  Background,
  Controls,
  Panel,
  Handle,
  Position,
  applyNodeChanges,
  applyEdgeChanges,
  addEdge
} from 'reactflow';
import 'reactflow/dist/style.css';
import { ZoomIn, ZoomOut, Trash2, Undo2, Redo2, Plus, Settings, Grid3X3, Sliders, MousePointer, Hand } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import PropertiesPanel from '@/components/PropertiesPanel';

// Custom Brain Node component with pulsating animation
const BrainNode = ({ data, selected }) => {
  return (
    <div className={`brain-node ${selected ? 'selected' : ''}`} style={{ position: 'relative' }}>
      {/* Top handle for connections - positioned to be clearly visible */}
      <Handle
        type="target"
        position={Position.Top}
        id="top"
        style={{
          width: '12px',
          height: '12px',
          background: '#60a5fa',
          border: '2px solid #1e293b',
          top: '-10px',
          zIndex: 10
        }}
      />
      
      {/* Left handle for connections - positioned to be clearly visible */}
      <Handle
        type="target"
        position={Position.Left}
        id="left"
        style={{
          width: '12px',
          height: '12px',
          background: '#60a5fa',
          border: '2px solid #1e293b',
          left: '-10px',
          zIndex: 10
        }}
      />
      
      {/* Node content with glassmorphic styling */}
      <div 
        className="brain-node-body"
        style={{
          background: 'rgba(59, 130, 246, 0.2)',
          backdropFilter: 'blur(8px)',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          borderRadius: '12px',
          boxShadow: selected 
            ? '0 8px 32px rgba(14, 165, 233, 0.25)' 
            : '0 8px 32px rgba(14, 165, 233, 0.15)',
          padding: '15px',
          minWidth: '180px',
          minHeight: '180px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          color: '#e2e8f0',
          textAlign: 'center',
          transition: 'all 0.3s ease-in-out',
          transform: selected ? 'scale(1.05)' : 'scale(1)'
        }}
      >
        {/* Node title */}
        <div 
          className="brain-title"
          style={{
            fontWeight: 'bold',
            fontSize: '1.25rem',
            marginBottom: '8px',
            textShadow: '0 2px 4px rgba(0, 0, 0, 0.3)',
            color: '#f8fafc'
          }}
        >
          {data.label}
        </div>
        
        {/* Node description */}
        {data.description && (
          <div 
            className="brain-description"
            style={{
              fontSize: '0.875rem',
              color: '#cbd5e1',
              maxWidth: '90%'
            }}
          >
            {data.description}
          </div>
        )}
        
        {/* Visual node indicator - pulsating circle */}
        <div 
          className="brain-indicator"
          style={{
            width: '60px',
            height: '60px',
            background: 'radial-gradient(circle, rgba(56, 189, 248, 0.8) 0%, rgba(59, 130, 246, 0.4) 70%)',
            borderRadius: '50%',
            margin: '12px auto',
            animation: 'pulse 2s infinite',
            boxShadow: '0 0 15px rgba(56, 189, 248, 0.6)',
            position: 'relative'
          }}
        >
          <div 
            style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              width: '30px',
              height: '30px',
              background: 'rgba(255, 255, 255, 0.8)',
              borderRadius: '50%',
              boxShadow: '0 0 10px rgba(255, 255, 255, 0.8)'
            }}
          />
        </div>
      </div>
      
      {/* Right handle for connections */}
      <Handle
        type="source"
        position={Position.Right}
        id="right"
        style={{
          width: '12px',
          height: '12px',
          background: '#60a5fa',
          border: '2px solid #1e293b',
          right: '-10px',
          zIndex: 10
        }}
      />
      
      {/* Bottom handle for connections */}
      <Handle
        type="source"
        position={Position.Bottom}
        id="bottom"
        style={{
          width: '12px',
          height: '12px',
          background: '#60a5fa',
          border: '2px solid #1e293b',
          bottom: '-10px',
          zIndex: 10
        }}
      />
    </div>
  );
};

// Workflow Node component with proper handles for connections
const WorkflowNode = ({ data, selected }) => {
  const nodeColor = data.color || getNodeColorByType(data.type);
  
  return (
    <div className={`workflow-node ${selected ? 'selected' : ''}`}>
      {/* Top handle for connections */}
      <Handle
        type="target"
        position={Position.Top}
        id="top"
        style={{
          width: '12px',
          height: '12px',
          background: nodeColor,
          border: '2px solid #1e293b',
          top: '-6px'
        }}
      />
      
      {/* Main node with glassmorphic styling */}
      <div
        className="workflow-node-container"
        style={{
          background: `rgba(${hexToRgb(nodeColor)}, 0.2)`,
          backdropFilter: 'blur(8px)',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          borderRadius: '6px',
          overflow: 'hidden',
          boxShadow: selected 
            ? `0 8px 32px rgba(${hexToRgb(nodeColor)}, 0.25)` 
            : `0 8px 32px rgba(${hexToRgb(nodeColor)}, 0.15)`,
          minWidth: '120px',
          minHeight: '50px',
          color: '#e2e8f0',
          transition: 'all 0.2s ease'
        }}
      >
        {/* Node header */}
        <div
          className="workflow-node-header"
          style={{
            background: `rgba(${hexToRgb(nodeColor)}, 0.7)`,
            padding: '8px 12px',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
            fontWeight: 'bold',
            fontSize: '1rem',
            color: '#ffffff',
            textShadow: '0 1px 2px rgba(0, 0, 0, 0.2)'
          }}
        >
          {data.label}
        </div>
        
        {/* Node content/subtitle */}
        <div
          className="workflow-node-content"
          style={{
            padding: '8px 12px',
            fontWeight: 'normal',
            fontSize: '0.875rem',
            color: '#e2e8f0'
          }}
        >
          {data.subtitle || data.type}
        </div>
      </div>
      
      {/* Left handles for inputs */}
      {data.inputs && data.inputs.map((input, index) => (
        <Handle
          key={`input-${index}`}
          type="target"
          position={Position.Left}
          id={`input-${index}`}
          style={{
            width: '10px',
            height: '10px',
            background: nodeColor,
            border: '2px solid #1e293b',
            left: '-5px',
            top: 50 + (index * 20) + '%'
          }}
        />
      ))}
      
      {/* Right handles for outputs */}
      {data.outputs && data.outputs.map((output, index) => (
        <Handle
          key={`output-${index}`}
          type="source"
          position={Position.Right}
          id={`output-${index}`}
          style={{
            width: '10px',
            height: '10px',
            background: nodeColor,
            border: '2px solid #1e293b',
            right: '-5px',
            top: 50 + (index * 20) + '%'
          }}
        />
      ))}
      
      {/* Bottom handle */}
      <Handle
        type="source"
        position={Position.Bottom}
        id="bottom"
        style={{
          width: '12px',
          height: '12px',
          background: nodeColor,
          border: '2px solid #1e293b',
          bottom: '-6px'
        }}
      />
    </div>
  );
};

// Modern n8n Style Node
const N8nNode = ({ data, selected }) => {
  const nodeColor = data.color || getNodeColorByType(data.type);
  
  return (
    <div className={`n8n-node ${selected ? 'selected' : ''}`}>
      {/* Main node container with glassmorphic styling */}
      <div
        className="n8n-node-container"
        style={{
          display: 'flex',
          flexDirection: 'column',
          background: `rgba(${hexToRgb(nodeColor)}, 0.2)`,
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255, 255, 255, 0.15)',
          borderRadius: '8px',
          overflow: 'hidden',
          boxShadow: selected 
            ? `0 8px 32px rgba(${hexToRgb(nodeColor)}, 0.35)` 
            : `0 8px 32px rgba(${hexToRgb(nodeColor)}, 0.2)`,
          width: '140px',
          color: '#e2e8f0',
          transition: 'all 0.2s ease'
        }}
      >
        {/* Node header */}
        <div
          className="n8n-node-header"
          style={{
            background: nodeColor,
            padding: '10px',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
            fontWeight: 'bold',
            fontSize: '1rem',
            color: '#ffffff',
            textAlign: 'center',
            textShadow: '0 1px 2px rgba(0, 0, 0, 0.3)'
          }}
        >
          {data.label}
        </div>
        
        {/* Node subtitle */}
        <div
          className="n8n-node-subtitle"
          style={{
            padding: '8px 10px',
            fontWeight: 'normal',
            fontSize: '0.875rem',
            color: '#e2e8f0',
            textAlign: 'center',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)'
          }}
        >
          {data.subtitle || data.type}
        </div>
      </div>
      
      {/* Left handles for inputs */}
      {data.inputs && data.inputs.map((input, index) => (
        <Handle
          key={`input-${index}`}
          type="target"
          position={Position.Left}
          id={`input-${index}`}
          style={{
            width: '10px',
            height: '10px',
            background: '#60a5fa',
            border: '2px solid #1e293b',
            left: '-6px',
            top: `${40 + (index * 30)}px`
          }}
        />
      ))}
      
      {/* Right handles for outputs */}
      {data.outputs && data.outputs.map((output, index) => (
        <Handle
          key={`output-${index}`}
          type="source"
          position={Position.Right}
          id={`output-${index}`}
          style={{
            width: '10px',
            height: '10px',
            background: '#60a5fa',
            border: '2px solid #1e293b',
            right: '-6px',
            top: `${40 + (index * 30)}px`
          }}
        />
      ))}
    </div>
  );
};

// API Call Node
const ApiNode = ({ data, selected }) => {
  return (
    <div className={`api-node ${selected ? 'selected' : ''}`}>
      {/* Main node with glassmorphic styling */}
      <div
        className="api-node-container"
        style={{
          background: 'rgba(6, 182, 212, 0.15)',
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255, 255, 255, 0.15)',
          borderRadius: '8px',
          overflow: 'hidden',
          boxShadow: selected 
            ? '0 8px 32px rgba(6, 182, 212, 0.35)' 
            : '0 8px 32px rgba(6, 182, 212, 0.2)',
          width: '140px',
          transition: 'all 0.2s ease',
          position: 'relative'
        }}
      >
        {/* Node header */}
        <div
          className="api-node-header"
          style={{
            background: '#06b6d4',
            padding: '10px',
            borderTopLeftRadius: '8px',
            borderTopRightRadius: '8px',
            fontWeight: 'bold',
            fontSize: '1rem',
            color: '#ffffff',
            textAlign: 'center',
            textShadow: '0 1px 2px rgba(0, 0, 0, 0.3)'
          }}
        >
          {data.label}
        </div>
        
        {/* Node content */}
        <div
          className="api-node-content"
          style={{
            padding: '8px 10px',
            fontWeight: 'normal',
            fontSize: '0.875rem',
            color: '#e2e8f0',
            textAlign: 'center'
          }}
        >
          {data.subtitle || 'API Call'}
        </div>
      </div>

      {/* Left handle */}
      <Handle
        type="target"
        position={Position.Left}
        id="api-input"
        style={{
          width: '10px',
          height: '10px',
          background: '#06b6d4',
          border: '2px solid #1e293b',
          left: '-6px',
          top: '50%'
        }}
      />
      
      {/* Right handle */}
      <Handle
        type="source"
        position={Position.Right}
        id="api-output"
        style={{
          width: '10px',
          height: '10px',
          background: '#06b6d4',
          border: '2px solid #1e293b',
          right: '-6px',
          top: '50%'
        }}
      />
    </div>
  );
};

// Prompt Node (Start)
const PromptStartNode = ({ data, selected }) => {
  return (
    <div className={`prompt-start-node ${selected ? 'selected' : ''}`}>
      {/* Main node with glassmorphic styling */}
      <div
        className="prompt-start-node-container"
        style={{
          background: 'rgba(56, 189, 248, 0.15)',
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255, 255, 255, 0.15)',
          borderRadius: '8px',
          overflow: 'hidden',
          boxShadow: selected 
            ? '0 8px 32px rgba(56, 189, 248, 0.35)' 
            : '0 8px 32px rgba(56, 189, 248, 0.2)',
          width: '140px',
          transition: 'all 0.2s ease',
          position: 'relative'
        }}
      >
        {/* Node header */}
        <div
          className="prompt-start-node-header"
          style={{
            background: '#38bdf8',
            padding: '10px',
            borderTopLeftRadius: '8px',
            borderTopRightRadius: '8px',
            fontWeight: 'bold',
            fontSize: '1rem',
            color: '#ffffff',
            textAlign: 'center',
            textShadow: '0 1px 2px rgba(0, 0, 0, 0.3)'
          }}
        >
          {data.label || 'Start'}
        </div>
        
        {/* Node content */}
        <div
          className="prompt-start-node-content"
          style={{
            padding: '8px 10px',
            fontWeight: 'normal',
            fontSize: '0.875rem',
            color: '#e2e8f0',
            textAlign: 'center'
          }}
        >
          {data.subtitle || 'Prompt'}
        </div>
      </div>
      
      {/* Right handle */}
      <Handle
        type="source"
        position={Position.Right}
        id="prompt-start-output"
        style={{
          width: '10px',
          height: '10px',
          background: '#38bdf8',
          border: '2px solid #1e293b',
          right: '-6px',
          top: '50%'
        }}
      />
    </div>
  );
};

// Prompt Node (Middle)
const PromptNode = ({ data, selected }) => {
  return (
    <div className={`prompt-node ${selected ? 'selected' : ''}`}>
      {/* Main node with glassmorphic styling */}
      <div
        className="prompt-node-container"
        style={{
          background: 'rgba(234, 88, 12, 0.15)',
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255, 255, 255, 0.15)',
          borderRadius: '8px',
          overflow: 'hidden',
          boxShadow: selected 
            ? '0 8px 32px rgba(234, 88, 12, 0.35)' 
            : '0 8px 32px rgba(234, 88, 12, 0.2)',
          width: '140px',
          transition: 'all 0.2s ease',
          position: 'relative'
        }}
      >
        {/* Node header */}
        <div
          className="prompt-node-header"
          style={{
            background: '#ea580c',
            padding: '10px',
            borderTopLeftRadius: '8px',
            borderTopRightRadius: '8px',
            fontWeight: 'bold',
            fontSize: '1rem',
            color: '#ffffff',
            textAlign: 'center',
            textShadow: '0 1px 2px rgba(0, 0, 0, 0.3)'
          }}
        >
          {data.label || 'Prompt'}
        </div>
        
        {/* Node content */}
        <div
          className="prompt-node-content"
          style={{
            padding: '8px 10px',
            fontWeight: 'normal',
            fontSize: '0.875rem',
            color: '#e2e8f0',
            textAlign: 'center'
          }}
        >
          {data.subtitle || 'Prompt'}
        </div>
      </div>

      {/* Left handle */}
      <Handle
        type="target"
        position={Position.Left}
        id="prompt-input"
        style={{
          width: '10px',
          height: '10px',
          background: '#ea580c',
          border: '2px solid #1e293b',
          left: '-6px',
          top: '50%'
        }}
      />
      
      {/* Right handle */}
      <Handle
        type="source"
        position={Position.Right}
        id="prompt-output"
        style={{
          width: '10px',
          height: '10px',
          background: '#ea580c',
          border: '2px solid #1e293b',
          right: '-6px',
          top: '50%'
        }}
      />
    </div>
  );
};

// Helper function to convert hex to rgb
function hexToRgb(hex) {
  // Default blue if no color provided
  if (!hex) return '59, 130, 246';
  
  // Remove # if present
  hex = hex.replace('#', '');
  
  // Convert 3-digit hex to 6-digits
  if (hex.length === 3) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  }
  
  // Parse hex values
  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);
  
  return `${r}, ${g}, ${b}`;
}

// Get node color based on type
function getNodeColorByType(type) {
  const typeColors = {
    'action': '#3b82f6',    // blue
    'trigger': '#ef4444',   // red
    'helper': '#10b981',    // green
    'transformer': '#8b5cf6', // purple
    'api': '#06b6d4',       // cyan
    'prompt': '#ea580c',    // orange
    'start': '#38bdf8',     // light blue
  };
  
  return typeColors[type?.toLowerCase()] || '#3b82f6';
}

// Initial nodes
const initialNodes = [
  {
    id: 'start-node',
    type: 'promptStartNode',
    position: { x: 100, y: 100 },
    data: { 
      label: 'Start',
      subtitle: 'Prompt',
    },
  },
  {
    id: 'prompt-node',
    type: 'promptNode',
    position: { x: 100, y: 250 },
    data: { 
      label: 'Prompt',
      subtitle: 'Prompt',
    },
  },
  {
    id: 'new-node',
    type: 'n8nNode',
    position: { x: 300, y: 100 },
    data: { 
      label: 'New Node',
      subtitle: 'Prompt',
      inputs: [{ id: '1', name: 'Input' }],
      outputs: [{ id: '1', name: 'Output' }]
    },
  },
  {
    id: 'api-node',
    type: 'apiNode',
    position: { x: 300, y: 250 },
    data: { 
      label: 'API Call',
      subtitle: 'API Call',
    },
  },
  {
    id: 'brain-node',
    type: 'brainNode',
    position: { x: 500, y: 175 },
    data: { 
      label: 'The Brain',
      description: 'Central thought hub',
    },
  },
];

// Initial edges with more professional styling
const initialEdges = [
  {
    id: 'edge-start-to-new',
    source: 'start-node',
    target: 'new-node',
    sourceHandle: 'prompt-start-output',
    targetHandle: 'input-0',
    animated: true,
    style: { stroke: '#38bdf8', strokeWidth: 2 }
  },
  {
    id: 'edge-prompt-to-api',
    source: 'prompt-node',
    target: 'api-node',
    sourceHandle: 'prompt-output',
    targetHandle: 'api-input',
    animated: true,
    style: { stroke: '#ea580c', strokeWidth: 2 }
  },
  {
    id: 'edge-new-to-brain',
    source: 'new-node',
    target: 'brain-node',
    sourceHandle: 'output-0',
    targetHandle: 'top',
    animated: true,
    style: { stroke: '#38bdf8', strokeWidth: 2 }
  },
  {
    id: 'edge-api-to-brain',
    source: 'api-node',
    target: 'brain-node',
    sourceHandle: 'api-output',
    targetHandle: 'top',
    animated: true,
    style: { stroke: '#06b6d4', strokeWidth: 2 }
  }
];

// Advanced Database Node component
const DatabaseNode = ({ data, selected }) => {
  const mainColor = "#6d28d9"; // Purple color like in the reference image
  const subnodes = data.subnodes || [];
  
  // Create categorized input/output sections
  const inputs = subnodes.filter(subnode => subnode.type === 'input' || subnode.direction === 'input');
  const outputs = subnodes.filter(subnode => subnode.type === 'output' || subnode.direction === 'output');
  
  // Group inputs by category (Input 1D, Input 2D, etc.)
  const groupedInputs = {};
  inputs.forEach(input => {
    const category = input.category || 'default';
    if (!groupedInputs[category]) {
      groupedInputs[category] = [];
    }
    groupedInputs[category].push(input);
  });
  
  // Get database row pairs (input + output with matching rowId)
  const dbRows = [];
  // Find all unique row IDs
  const rowIds = new Set();
  subnodes.forEach(node => {
    if (node.rowId) rowIds.add(node.rowId);
  });
  
  // Group nodes by row ID
  rowIds.forEach(rowId => {
    const rowInputs = subnodes.filter(n => n.rowId === rowId && (n.type === 'input' || n.direction === 'input'));
    const rowOutputs = subnodes.filter(n => n.rowId === rowId && (n.type === 'output' || n.direction === 'output'));
    if (rowInputs.length > 0 || rowOutputs.length > 0) {
      dbRows.push({
        id: rowId,
        inputs: rowInputs,
        outputs: rowOutputs
      });
    }
  });
  
  // Helper function to create connector dots
  const createConnectorDot = (color, side, top) => ({
    position: 'absolute',
    width: '10px',
    height: '10px',
    background: color,
    borderRadius: '50%',
    border: '2px solid #1e293b',
    [side]: '-5px',
    top: `${top}px`,
    zIndex: 5
  });
  
  // Calculate regular input/output sections
  const headerHeight = 40;
  const individualOutputs = outputs.filter(o => !o.rowId);
  const individualInputs = inputs.filter(i => !i.rowId);
  
  const outputSectionHeight = Math.max(individualOutputs.length * 28, 28); // At least 1 line height
  const inputSectionHeight = Object.values(groupedInputs)
    .filter(group => group[0].category !== 'db-row')
    .reduce((acc, group) => {
      return acc + (30 + (group.length * 28)); // Group header + items
    }, 0);
  
  // Calculate height for database rows section
  const dbRowsHeight = dbRows.length > 0 ? dbRows.length * 40 + 30 : 0; // Each row + section header
  
  const totalHeight = headerHeight + outputSectionHeight + inputSectionHeight + dbRowsHeight + 20; // 20px padding
  const nodeWidth = 190; // Wider than standard nodes
  
  // If there are no inputs or outputs, add default handles to the sides
  const hasNoConnections = inputs.length === 0 && outputs.length === 0;
  
  return (
    <div 
      className={`database-node ${selected ? 'selected' : ''}`}
      style={{
        position: 'relative',
        minHeight: `${totalHeight}px`,
        width: `${nodeWidth}px`,
        backgroundColor: '#4c1d95', // Dark purple background
        border: selected ? '2px solid #8b5cf6' : '1px solid rgba(139, 92, 246, 0.5)',
        borderRadius: '8px',
        color: 'white',
        textShadow: '0 1px 2px rgba(0, 0, 0, 0.5)',
        boxShadow: selected 
          ? '0 0 0 2px rgba(139, 92, 246, 0.3), 0 8px 20px rgba(0, 0, 0, 0.4)' 
          : '0 4px 12px rgba(0, 0, 0, 0.3)',
        padding: '0',
        transition: 'all 0.2s ease',
        fontSize: '12px'
      }}
    >
      {/* Header Section */}
      <div
        className="node-header"
        style={{
          padding: '10px 14px',
          borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
          textAlign: 'center',
          fontWeight: 'bold',
          fontSize: '14px',
          height: `${headerHeight}px`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'relative',
          background: 'linear-gradient(to bottom, rgba(109, 40, 217, 0.7), rgba(76, 29, 149, 0.5))'
        }}
      >
        {data.label || 'Database'}
        
        {/* Default handles if no connections are defined */}
        {hasNoConnections && (
          <>
            {/* Left handle */}
            <div style={{
              position: 'absolute',
              left: '-6px',
              top: '50%',
              transform: 'translateY(-50%)',
              width: '12px',
              height: '12px',
              background: '#3b82f6',
              borderRadius: '50%',
              border: '2px solid #1e293b',
              zIndex: 5
            }} />
            
            <Handle
              type="target"
              position={Position.Left}
              id="default-left"
              style={{
                width: '16px',
                height: '16px',
                left: '-8px',
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'transparent',
                border: 'none',
                zIndex: 10
              }}
            />
            
            {/* Right handle */}
            <div style={{
              position: 'absolute',
              right: '-6px', 
              top: '50%',
              transform: 'translateY(-50%)',
              width: '12px',
              height: '12px',
              background: '#22c55e',
              borderRadius: '50%',
              border: '2px solid #1e293b',
              zIndex: 5
            }} />
            
            <Handle
              type="source"
              position={Position.Right}
              id="default-right"
              style={{
                width: '16px',
                height: '16px',
                right: '-8px',
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'transparent',
                border: 'none',
                zIndex: 10
              }}
            />
          </>
        )}
      </div>
      
      {/* Database table row sections */}
      {dbRows.length > 0 && (
        <div className="database-rows-section" style={{ 
          padding: '5px 0px', 
          borderBottom: '1px solid rgba(255, 255, 255, 0.1)'
        }}>
          <div className="db-rows-header" style={{ 
            padding: '5px 10px',
            fontSize: '13px',
            fontWeight: 'bold',
            color: 'rgba(255, 255, 255, 0.8)'
          }}>
            Database Rows
          </div>
          
          {/* Render each row with its input and output */}
          {dbRows.map((row, rowIndex) => (
            <div 
              key={`db-row-${rowIndex}`}
              className="db-row"
              style={{
                display: 'flex',
                padding: '5px 15px',
                height: '36px',
                backgroundColor: rowIndex % 2 === 0 ? 'rgba(0, 0, 0, 0.2)' : 'transparent',
                justifyContent: 'space-between',
                alignItems: 'center',
                position: 'relative'
              }}
            >
              {/* Left/Input Side */}
              <div className="db-row-input" style={{ position: 'relative' }}>
                {/* Blue connector dot */}
                <div style={{
                  position: 'absolute',
                  left: '-20px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  width: '12px',
                  height: '12px',
                  background: '#3b82f6',
                  borderRadius: '50%',
                  border: '2px solid #1e293b',
                  zIndex: 5
                }} />
                
                <span>{row.inputs[0]?.label || `Row ${rowIndex + 1}`}</span>
                
                {/* Input handle */}
                <Handle
                  type="target"
                  position={Position.Left}
                  id={`db-row-input-${rowIndex}`}
                  style={{
                    width: '16px',
                    height: '16px',
                    left: '-22px',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    background: 'transparent',
                    border: 'none',
                    zIndex: 10
                  }}
                />
              </div>
              
              {/* Right/Output Side */}
              <div className="db-row-output" style={{ position: 'relative' }}>
                <span>{row.outputs[0]?.label || `Row ${rowIndex + 1}`}</span>
                
                {/* Green connector dot */}
                <div style={{
                  position: 'absolute',
                  right: '-20px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  width: '12px',
                  height: '12px',
                  background: '#22c55e',
                  borderRadius: '50%',
                  border: '2px solid #1e293b',
                  zIndex: 5
                }} />
                
                {/* Output handle */}
                <Handle
                  type="source"
                  position={Position.Right}
                  id={`db-row-output-${rowIndex}`}
                  style={{
                    width: '16px',
                    height: '16px',
                    right: '-22px',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    background: 'transparent',
                    border: 'none',
                    zIndex: 10
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Regular Output Section (always at the top after rows) */}
      {individualOutputs.length > 0 && (
        <div className="outputs-section" style={{ padding: '10px 10px 5px 10px' }}>
          {individualOutputs.map((output, index) => {
            return (
              <div 
                key={`output-${index}`}
                className="output-item"
                style={{
                  position: 'relative',
                  padding: '4px 10px',
                  margin: '2px 0',
                  height: '24px',
                  display: 'flex',
                  alignItems: 'center'
                }}
              >
                {/* Visible green connector dot */}
                <div style={{
                  position: 'absolute',
                  right: '-6px',
                  top: '12px',
                  width: '12px',
                  height: '12px',
                  background: '#22c55e',
                  borderRadius: '50%',
                  border: '2px solid #1e293b',
                  zIndex: 5
                }} />
                
                <span style={{ marginLeft: '4px' }}>{output.label || `Output ${index + 1}`}</span>
                
                {/* Connection handle for this output */}
                <Handle
                  type="source"
                  position={Position.Right}
                  id={`output-${index}`}
                  style={{
                    width: '16px',
                    height: '16px',
                    right: '-8px',
                    top: '12px',
                    opacity: 1,
                    background: 'transparent',
                    border: 'none',
                    zIndex: 10
                  }}
                />
              </div>
            );
          })}
        </div>
      )}
      
      {/* Regular Input Section (grouped by categories) */}
      {Object.entries(groupedInputs)
        .filter(([category]) => category !== 'db-row')
        .map(([category, items], groupIndex) => (
          <div 
            key={`group-${groupIndex}`}
            className="input-group"
            style={{
              marginBottom: '8px',
              padding: '5px 10px'
            }}
          >
            {/* Group header */}
            <div 
              className="input-group-header"
              style={{
                fontWeight: 'bold',
                fontSize: '13px',
                marginBottom: '4px',
                paddingLeft: '14px',
                opacity: 0.9,
                position: 'relative'
              }}
            >
              <span style={{ 
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px'
              }}>
                {/* Small expand/collapse icon */}
                <svg width="10" height="10" viewBox="0 0 10 10">
                  <path 
                    d="M2 3L5 7L8 3" 
                    fill="none" 
                    stroke="white" 
                    strokeWidth="1.5" 
                    strokeLinecap="round"
                  />
                </svg>
                {category === 'default' ? 'Input' : category}
              </span>
            </div>
            
            {/* Group items */}
            <div className="input-items" style={{ marginLeft: '10px' }}>
              {items.map((input, itemIndex) => (
                <div 
                  key={`input-${groupIndex}-${itemIndex}`}
                  className="input-item"
                  style={{
                    position: 'relative',
                    padding: '4px 10px',
                    margin: '2px 0',
                    height: '24px',
                    display: 'flex',
                    alignItems: 'center',
                  }}
                >
                  {/* Visible blue connector dot */}
                  <div style={{
                    position: 'absolute',
                    left: '-6px',
                    top: '12px',
                    width: '12px',
                    height: '12px',
                    background: '#3b82f6',
                    borderRadius: '50%',
                    border: '2px solid #1e293b',
                    zIndex: 5
                  }} />
                  
                  <span style={{ marginLeft: '10px' }}>{input.label || `Input ${itemIndex + 1}`}</span>
                  
                  {/* Connection handle for this input */}
                  <Handle
                    type="target"
                    position={Position.Left}
                    id={`input-${groupIndex}-${itemIndex}`}
                    style={{
                      width: '16px',
                      height: '16px',
                      left: '-8px',
                      top: '12px',
                      opacity: 1,
                      background: 'transparent',
                      border: 'none',
                      zIndex: 10
                    }}
                  />
                </div>
              ))}
            </div>
          </div>
        ))
      }
    </div>
  );
};

// Define node types
const nodeTypes = {
  brainNode: BrainNode,
  workflowNode: WorkflowNode,
  n8nNode: N8nNode,
  apiNode: ApiNode,
  promptStartNode: PromptStartNode,
  promptNode: PromptNode,
  databaseNode: DatabaseNode
};

// Node categories for the sidebar
const nodeCategories = [
  {
    name: 'Basic',
    items: [
      { type: 'brainNode', label: 'The Brain', description: 'Central node for connections', color: '#3b82f6' },
      { type: 'n8nNode', label: 'Standard Node', subtitle: 'Process', color: '#8b5cf6' },
    ]
  },
  {
    name: 'Flow',
    items: [
      { type: 'promptStartNode', label: 'Start', subtitle: 'Entry Point', color: '#38bdf8' },
      { type: 'workflowNode', label: 'Workflow', subtitle: 'Process Step', color: '#3b82f6' },
    ]
  },
  {
    name: 'Data',
    items: [
      { 
        type: 'databaseNode', 
        label: 'Database', 
        subtitle: 'Data Storage', 
        color: '#06b6d4',
        // Pre-populate the database with 4 rows automatically
        subnodes: [
          // Row 1
          {
            label: "Input 1",
            type: 'input',
            direction: 'input',
            category: 'db-row',
            rowId: 'row-1'
          },
          {
            label: "Output 1",
            type: 'output',
            direction: 'output',
            rowId: 'row-1'
          },
          // Row 2
          {
            label: "Input 2",
            type: 'input',
            direction: 'input',
            category: 'db-row',
            rowId: 'row-2'
          },
          {
            label: "Output 2",
            type: 'output',
            direction: 'output',
            rowId: 'row-2'
          },
          // Row 3
          {
            label: "Input 3",
            type: 'input',
            direction: 'input',
            category: 'db-row',
            rowId: 'row-3'
          },
          {
            label: "Output 3",
            type: 'output',
            direction: 'output',
            rowId: 'row-3'
          },
          // Row 4
          {
            label: "Input 4",
            type: 'input',
            direction: 'input',
            category: 'db-row',
            rowId: 'row-4'
          },
          {
            label: "Output 4",
            type: 'output',
            direction: 'output',
            rowId: 'row-4'
          }
        ]
      },
    ]
  },
  {
    name: 'Actions',
    items: [
      { type: 'apiNode', label: 'API Call', subtitle: 'External Service', color: '#06b6d4' },
      { type: 'promptNode', label: 'Prompt', subtitle: 'User Input', color: '#ea580c' },
    ]
  }
];

// Left Sidebar Component
const LeftSidebar = ({ isOpen, onToggle, onDragStart }) => {
  return (
    <div 
      className={`left-sidebar ${isOpen ? 'open' : 'closed'}`}
      style={{
        position: 'absolute',
        top: '0',
        left: '0',
        height: '100%',
        width: isOpen ? '250px' : '0',
        background: 'rgba(15, 23, 42, 0.85)',
        backdropFilter: 'blur(10px)',
        borderRight: '1px solid rgba(255, 255, 255, 0.1)',
        transition: 'width 0.3s ease',
        zIndex: 10,
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      <div className="sidebar-header p-4 border-b border-slate-700/50">
        <h3 className="text-lg font-semibold text-slate-200">Node Palette</h3>
        <p className="text-xs text-slate-400">Drag nodes to the canvas</p>
      </div>
      
      <div className="sidebar-content flex-1 overflow-y-auto p-2">
        {nodeCategories.map((category, catIndex) => (
          <div key={catIndex} className="mb-4">
            <h4 className="text-sm font-medium text-slate-300 mb-2 px-2">{category.name}</h4>
            <div className="grid grid-cols-1 gap-2">
              {category.items.map((item, itemIndex) => (
                <div
                  key={itemIndex}
                  className="node-item bg-slate-800/50 hover:bg-slate-700/50 rounded p-2 cursor-grab transition-colors"
                  onDragStart={(event) => onDragStart(event, item)}
                  draggable
                >
                  <div className="flex items-center">
                    <div 
                      className="w-3 h-3 rounded-full mr-2"
                      style={{ backgroundColor: item.color }}
                    ></div>
                    <span className="text-sm text-slate-200">{item.label}</span>
                  </div>
                  <div className="text-xs text-slate-400 ml-5">{item.subtitle || item.description}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      
      <button
        className="sidebar-toggle absolute -right-4 top-1/2 transform -translate-y-1/2 bg-slate-800 border border-slate-700 rounded-full w-8 h-8 flex items-center justify-center"
        onClick={onToggle}
        title={isOpen ? "Close sidebar" : "Open sidebar"}
      >
        {isOpen ? 
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300">
            <path d="M15 18l-6-6 6-6" />
          </svg>
          :
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300">
            <path d="M9 18l6-6-6-6" />
          </svg>
        }
      </button>
    </div>
  );
};

// Main component
function FlowWithProvider() {
  return (
    <ReactFlowProvider>
      <MindMapFlow />
    </ReactFlowProvider>
  );
}

// MindMap Flow Component
function MindMapFlow() {
  // State
  const [nodes, setNodes] = useState(initialNodes);
  const [edges, setEdges] = useState(initialEdges);
  const [selectedElements, setSelectedElements] = useState({ nodes: [], edges: [] });
  const [selectedNode, setSelectedNode] = useState(null);
  const [selectedEdge, setSelectedEdge] = useState(null);
  const [reactFlowInstance, setReactFlowInstance] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [propertiesPanelOpen, setPropertiesPanelOpen] = useState(true);
  
  // Refs
  const reactFlowWrapper = useRef(null);
  
  // History for undo/redo
  const [history, setHistory] = useState([{ nodes: initialNodes, edges: initialEdges }]);
  const [historyIndex, setHistoryIndex] = useState(0);
  
  // Add to history whenever nodes or edges change
  const addToHistory = useCallback((newNodes, newEdges) => {
    const newState = { nodes: newNodes, edges: newEdges };
    if (JSON.stringify(newState) !== JSON.stringify(history[historyIndex])) {
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(newState);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    }
  }, [history, historyIndex]);
  
  // Handle node changes
  const onNodesChange = useCallback(
    (changes) => {
      setNodes((nds) => {
        const newNodes = applyNodeChanges(changes, nds);
        addToHistory(newNodes, edges);
        return newNodes;
      });
    },
    [edges, addToHistory]
  );
  
  // Handle edge changes
  const onEdgesChange = useCallback(
    (changes) => {
      setEdges((eds) => {
        const newEdges = applyEdgeChanges(changes, eds);
        addToHistory(nodes, newEdges);
        return newEdges;
      });
    },
    [nodes, addToHistory]
  );
  
  // Handle new connections
  const onConnect = useCallback(
    (params) => {
      // Create edge with styling based on source node type
      const sourceNode = nodes.find(node => node.id === params.source);
      const edgeColor = sourceNode?.data?.color || getNodeColorByType(sourceNode?.data?.type) || '#3b82f6';
      
      const newEdge = {
        ...params,
        id: `edge-${Math.random().toString(36).substring(2, 9)}`,
        animated: true,
        style: { stroke: edgeColor, strokeWidth: 2 }
      };
      
      setEdges((eds) => {
        const newEdges = addEdge(newEdge, eds);
        addToHistory(nodes, newEdges);
        return newEdges;
      });
    },
    [nodes, addToHistory]
  );
  
  // Initialize ReactFlow instance
  const onInit = useCallback((instance) => {
    setReactFlowInstance(instance);
  }, []);
  
  // Handle selection change
  const onSelectionChange = useCallback(({ nodes, edges }) => {
    setSelectedElements({ nodes, edges });
    
    // Update selected node and edge
    if (nodes && nodes.length > 0) {
      setSelectedNode(nodes[0]);
      setSelectedEdge(null);
    } else if (edges && edges.length > 0) {
      setSelectedEdge(edges[0]);
      setSelectedNode(null);
    }
  }, []);
  
  // Delete selected elements
  const onDeleteSelected = useCallback(() => {
    if (selectedElements.nodes && selectedElements.nodes.length > 0) {
      const selectedNodeIds = selectedElements.nodes.map((node) => node.id);
      
      setNodes((nds) => {
        const newNodes = nds.filter((node) => !selectedNodeIds.includes(node.id));
        
        setEdges((eds) => {
          const newEdges = eds.filter(
            (edge) => !selectedNodeIds.includes(edge.source) && !selectedNodeIds.includes(edge.target)
          );
          
          addToHistory(newNodes, newEdges);
          return newEdges;
        });
        
        return newNodes;
      });
    } else if (selectedElements.edges && selectedElements.edges.length > 0) {
      const selectedEdgeIds = selectedElements.edges.map((edge) => edge.id);
      
      setEdges((eds) => {
        const newEdges = eds.filter((edge) => !selectedEdgeIds.includes(edge.id));
        addToHistory(nodes, newEdges);
        return newEdges;
      });
    }
  }, [selectedElements, nodes, addToHistory]);
  
  // Undo action
  const onUndo = useCallback(() => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      const { nodes: historyNodes, edges: historyEdges } = history[newIndex];
      
      setNodes(historyNodes);
      setEdges(historyEdges);
      setHistoryIndex(newIndex);
    }
  }, [history, historyIndex]);
  
  // Redo action
  const onRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      const { nodes: historyNodes, edges: historyEdges } = history[newIndex];
      
      setNodes(historyNodes);
      setEdges(historyEdges);
      setHistoryIndex(newIndex);
    }
  }, [history, historyIndex]);
  
  // Handle node drag start (for sidebar)
  const onDragStart = (event, nodeData) => {
    // Prepare the node data for transfer
    event.dataTransfer.setData('application/reactflow', JSON.stringify(nodeData));
    event.dataTransfer.effectAllowed = 'move';
  };
  
  // Handle drop event for new nodes
  const onDrop = useCallback(
    (event) => {
      event.preventDefault();
      
      if (!reactFlowInstance) return;
      
      // Get node data from drag event
      const data = JSON.parse(event.dataTransfer.getData('application/reactflow'));
      
      // Get position from drop coordinates
      const position = reactFlowInstance.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });
      
      // Create a new node
      const newNode = {
        id: `${data.type}-${Math.random().toString(36).substring(2, 9)}`,
        type: data.type,
        position,
        data: {
          ...data,
          label: data.label,
          subtitle: data.subtitle,
          color: data.color,
          inputs: data.inputs || [],
          outputs: data.outputs || []
        },
      };
      
      // Add the new node
      setNodes((nds) => {
        const newNodes = [...nds, newNode];
        addToHistory(newNodes, edges);
        return newNodes;
      });
    },
    [reactFlowInstance, edges, addToHistory]
  );
  
  // Handle drag over event (required for drop)
  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);
  
  // Toggle sidebar
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  // Node and edge data update handlers
  const updateNodeData = useCallback((nodeId, newData) => {
    setNodes((nds) => {
      const updatedNodes = nds.map(node => {
        if (node.id === nodeId) {
          // Special handling for database nodes to ensure subnodes are properly updated
          if (node.type === 'databaseNode' && newData.subnodes) {
            return {
              ...node,
              data: { 
                ...node.data, 
                ...newData,
                // Ensure subnodes are properly updated 
                subnodes: Array.isArray(newData.subnodes) ? [...newData.subnodes] : []
              }
            };
          }
          
          return {
            ...node,
            data: { ...node.data, ...newData }
          };
        }
        return node;
      });
      
      addToHistory(updatedNodes, edges);
      return updatedNodes;
    });
  }, [edges, addToHistory]);
  
  const updateNodeStyle = useCallback((nodeId, newStyle) => {
    setNodes((nds) => {
      const updatedNodes = nds.map(node => {
        if (node.id === nodeId) {
          return {
            ...node,
            style: { ...node.style, ...newStyle }
          };
        }
        return node;
      });
      
      addToHistory(updatedNodes, edges);
      return updatedNodes;
    });
  }, [edges, addToHistory]);
  
  const updateEdgeStyle = useCallback((edgeId, newStyle, animated) => {
    setEdges((eds) => {
      // Check if this is a delete operation
      if (newStyle && newStyle.delete) {
        // Remove the edge
        const updatedEdges = eds.filter(edge => edge.id !== edgeId);
        
        // Also deselect the edge
        if (selectedEdge && selectedEdge.id === edgeId) {
          setSelectedEdge(null);
        }
        
        addToHistory(nodes, updatedEdges);
        return updatedEdges;
      }
      
      // Otherwise, update the edge style
      const updatedEdges = eds.map(edge => {
        if (edge.id === edgeId) {
          return {
            ...edge,
            style: { ...edge.style, ...newStyle },
            animated: animated !== undefined ? animated : edge.animated
          };
        }
        return edge;
      });
      
      addToHistory(nodes, updatedEdges);
      return updatedEdges;
    });
  }, [nodes, addToHistory, selectedEdge]);
  
  // Toggle Properties Panel
  const togglePropertiesPanel = useCallback(() => {
    setPropertiesPanelOpen(prev => !prev);
  }, []);

  return (
    <div className="mindmap-container h-full relative" ref={reactFlowWrapper}>
      {/* Left Sidebar */}
      <LeftSidebar 
        isOpen={sidebarOpen} 
        onToggle={toggleSidebar} 
        onDragStart={onDragStart}
      />
      
      {/* Properties Panel */}
      <PropertiesPanel
        isOpen={propertiesPanelOpen}
        onToggle={togglePropertiesPanel}
        selectedNode={selectedNode}
        selectedEdge={selectedEdge}
        onUpdateNodeData={updateNodeData}
        onUpdateNodeStyle={updateNodeStyle}
        onUpdateEdgeStyle={updateEdgeStyle}
      />
      
      {/* Main Flow Area */}
      <div 
        className="flow-container h-full"
        style={{ 
          marginLeft: sidebarOpen ? '250px' : '0',
          marginRight: propertiesPanelOpen ? '300px' : '0',
          transition: 'margin 0.3s ease'
        }}
      >
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onInit={onInit}
          onSelectionChange={onSelectionChange}
          onDrop={onDrop}
          onDragOver={onDragOver}
          nodeTypes={nodeTypes}
          defaultViewport={{ x: 0, y: 0, zoom: 1 }}
          minZoom={0.2}
          maxZoom={4}
          snapToGrid={true}
          snapGrid={[10, 10]}
          fitView
          attributionPosition="bottom-right"
        >
          <Background color="#334155" gap={16} size={1} />
          <Controls />
          
          {/* Top Toolbar */}
          <Panel position="top-center" className="bg-slate-900/60 p-2 rounded-lg shadow-lg backdrop-blur-sm">
            <div className="flex items-center gap-2">
              {/* Selection Tool */}
              <Button
                variant="secondary"
                size="icon"
                title="Selection Tool (Select and move nodes)"
                onClick={() => {
                  // Enable selection mode (default)
                  setNodes((nds) => {
                    return nds.map(node => ({
                      ...node, 
                      draggable: true, // Ensure nodes are draggable in selection mode
                    }));
                  });
                }}
                className="text-slate-300 hover:text-blue-400"
              >
                <MousePointer size={18} />
              </Button>
              
              {/* Pan Tool */}
              <Button
                variant="ghost"
                size="icon"
                title="Pan Tool (Move canvas)"
                onClick={() => {
                  // Nothing to do here as pan is controlled by mouse middle button
                  // This is just a visual indicator for the user
                }}
                className="text-slate-300 hover:text-blue-400"
              >
                <Hand size={18} />
              </Button>
              
              <Separator orientation="vertical" className="h-6" />
              
              <Button
                variant="ghost"
                size="icon"
                title="Delete selected elements"
                onClick={onDeleteSelected}
                disabled={
                  (!selectedElements.nodes || selectedElements.nodes.length === 0) && 
                  (!selectedElements.edges || selectedElements.edges.length === 0)
                }
                className="text-slate-300 hover:text-red-400"
              >
                <Trash2 size={18} />
              </Button>
              
              <Separator orientation="vertical" className="h-6" />
              
              <Button
                variant="ghost"
                size="icon"
                title="Undo"
                onClick={onUndo}
                disabled={historyIndex <= 0}
                className="text-slate-300 hover:text-blue-300"
              >
                <Undo2 size={18} />
              </Button>
              
              <Button
                variant="ghost"
                size="icon"
                title="Redo"
                onClick={onRedo}
                disabled={historyIndex >= history.length - 1}
                className="text-slate-300 hover:text-blue-300"
              >
                <Redo2 size={18} />
              </Button>
              
              <Separator orientation="vertical" className="h-6" />
              
              <Button
                variant="ghost"
                size="icon"
                title="Show/Hide Grid"
                className="text-slate-300 hover:text-blue-300"
              >
                <Grid3X3 size={18} />
              </Button>
              
              <Button
                variant="ghost"
                size="icon"
                title="Add Node"
                className="text-slate-300 hover:text-green-300"
              >
                <Plus size={18} />
              </Button>
              
              <Button
                variant="ghost"
                size="icon"
                title="Properties Panel"
                onClick={togglePropertiesPanel}
                className={`text-slate-300 hover:text-yellow-300 ${propertiesPanelOpen ? 'bg-slate-700/50' : ''}`}
              >
                <Sliders size={18} />
              </Button>
              
              <Button
                variant="ghost"
                size="icon"
                title="Settings"
                className="text-slate-300 hover:text-yellow-300"
              >
                <Settings size={18} />
              </Button>
            </div>
          </Panel>
          
          {/* No bottom-right panel anymore - removed to avoid duplication */}
        </ReactFlow>
      </div>
    </div>
  );
}

export default FlowWithProvider;