import React, { useState, useCallback, useRef } from 'react';
import ReactFlow, {
  Background,
  Controls,
  Panel,
  applyNodeChanges,
  applyEdgeChanges,
  addEdge,
  BackgroundVariant
} from 'reactflow';
import 'reactflow/dist/style.css';
import { ZoomIn, ZoomOut, MinusCircle, Trash2, Undo2, Redo2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

// Custom Brain Node component
const BrainNode = ({ data, selected }) => {
  return (
    <div className={`brain-node ${selected ? 'selected' : ''}`}>
      {/* Node content with glassmorphic styling */}
      <div 
        className="brain-node-body"
        style={{
          background: 'rgba(59, 130, 246, 0.2)',
          backdropFilter: 'blur(8px)',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          borderRadius: '12px',
          boxShadow: selected 
            ? '0 8px 32px rgba(14, 165, 233, 0.25)' 
            : '0 8px 32px rgba(14, 165, 233, 0.15)',
          padding: '15px',
          minWidth: '150px',
          minHeight: '150px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          color: '#e2e8f0',
          textAlign: 'center',
          transition: 'all 0.3s ease-in-out',
          transform: selected ? 'scale(1.05)' : 'scale(1)'
        }}
      >
        {/* Node title */}
        <div 
          className="brain-title"
          style={{
            fontWeight: 'bold',
            fontSize: '1.25rem',
            marginBottom: '8px',
            textShadow: '0 2px 4px rgba(0, 0, 0, 0.3)',
            color: '#f8fafc'
          }}
        >
          {data.label}
        </div>
        
        {/* Node description */}
        {data.description && (
          <div 
            className="brain-description"
            style={{
              fontSize: '0.875rem',
              color: '#cbd5e1',
              maxWidth: '90%'
            }}
          >
            {data.description}
          </div>
        )}
        
        {/* Visual node indicator - pulsating circle */}
        <div 
          className="brain-indicator"
          style={{
            width: '60px',
            height: '60px',
            background: 'radial-gradient(circle, rgba(56, 189, 248, 0.8) 0%, rgba(59, 130, 246, 0.4) 70%)',
            borderRadius: '50%',
            margin: '12px auto',
            animation: 'pulse 2s infinite',
            boxShadow: '0 0 15px rgba(56, 189, 248, 0.6)',
            position: 'relative'
          }}
        >
          <div 
            style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              width: '30px',
              height: '30px',
              background: 'rgba(255, 255, 255, 0.8)',
              borderRadius: '50%',
              boxShadow: '0 0 10px rgba(255, 255, 255, 0.8)'
            }}
          />
        </div>
      </div>
    </div>
  );
};

// Custom Processor Node component
const ProcessorNode = ({ data, selected }) => {
  return (
    <div className={`processor-node ${selected ? 'selected' : ''}`}>
      {/* Node content */}
      <div 
        className="processor-node-body"
        style={{
          background: 'rgba(79, 70, 229, 0.2)',
          backdropFilter: 'blur(8px)',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          borderRadius: '8px',
          boxShadow: selected 
            ? '0 8px 32px rgba(79, 70, 229, 0.25)' 
            : '0 8px 32px rgba(79, 70, 229, 0.15)',
          padding: '12px',
          minWidth: '180px',
          color: '#e2e8f0',
          transition: 'all 0.3s ease-in-out',
          transform: selected ? 'scale(1.05)' : 'scale(1)'
        }}
      >
        {/* Node title */}
        <div 
          className="processor-title"
          style={{
            fontWeight: 'bold',
            fontSize: '1rem',
            marginBottom: '4px',
            color: '#f8fafc'
          }}
        >
          {data.label}
        </div>
        
        {/* Node type badge */}
        <div 
          style={{
            display: 'inline-block',
            fontSize: '0.75rem',
            padding: '2px 8px',
            borderRadius: '4px',
            background: 'rgba(79, 70, 229, 0.4)',
            marginBottom: '8px'
          }}
        >
          {data.type || 'Processor'}
        </div>
        
        {/* Node description */}
        {data.description && (
          <div 
            style={{
              fontSize: '0.875rem',
              color: '#cbd5e1',
              marginBottom: '8px',
              borderTop: '1px solid rgba(255, 255, 255, 0.1)',
              paddingTop: '8px'
            }}
          >
            {data.description}
          </div>
        )}
        
        {/* Input/Output section */}
        <div style={{ display: 'flex' }}>
          {/* Inputs */}
          <div style={{ flex: 1, borderRight: '1px solid rgba(255, 255, 255, 0.1)' }}>
            <div style={{ fontSize: '0.75rem', opacity: 0.7, marginBottom: '4px' }}>Inputs</div>
            {data.inputs && data.inputs.map((input, index) => (
              <div 
                key={index}
                style={{
                  fontSize: '0.8rem',
                  padding: '4px',
                  borderRadius: '4px',
                  background: 'rgba(255, 255, 255, 0.05)',
                  marginBottom: '4px',
                  position: 'relative'
                }}
              >
                {input.name}
              </div>
            ))}
          </div>
          
          {/* Outputs */}
          <div style={{ flex: 1, paddingLeft: '8px' }}>
            <div style={{ fontSize: '0.75rem', opacity: 0.7, marginBottom: '4px' }}>Outputs</div>
            {data.outputs && data.outputs.map((output, index) => (
              <div 
                key={index}
                style={{
                  fontSize: '0.8rem',
                  padding: '4px',
                  borderRadius: '4px',
                  background: 'rgba(255, 255, 255, 0.05)',
                  marginBottom: '4px',
                  textAlign: 'right',
                  position: 'relative'
                }}
              >
                {output.name}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// Custom Edge component with animated electrons
const ElectronEdge = ({ id, source, target, animated, selected, ...props }) => {
  return (
    <div className="react-flow__edge electron-edge">
      <svg>
        <defs>
          <marker
            id={`electron-arrowhead-${id}`}
            viewBox="0 0 10 10"
            refX="5"
            refY="5"
            markerWidth="3"
            markerHeight="3"
            orient="auto-start-reverse"
          >
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#38bdf8" />
          </marker>
        </defs>
        <path
          className={`react-flow__edge-path ${selected ? 'selected' : ''}`}
          d={`M${props.sourceX},${props.sourceY} C${props.sourceX + 100},${props.sourceY} ${props.targetX - 100},${props.targetY} ${props.targetX},${props.targetY}`}
          stroke="#38bdf8"
          strokeWidth={selected ? 3 : 2}
          strokeOpacity={0.8}
          fill="none"
          markerEnd={`url(#electron-arrowhead-${id})`}
          style={{
            filter: 'drop-shadow(0 0 5px rgba(56, 189, 248, 0.5))'
          }}
        />
        {animated && (
          <>
            <circle
              r="3"
              fill="#fff"
              style={{
                filter: 'drop-shadow(0 0 5px #38bdf8)',
                offsetPath: `path("M${props.sourceX},${props.sourceY} C${props.sourceX + 100},${props.sourceY} ${props.targetX - 100},${props.targetY} ${props.targetX},${props.targetY}")`,
                animation: 'electron-flow 3s infinite linear'
              }}
            />
            <circle
              r="2"
              fill="#fff"
              style={{
                filter: 'drop-shadow(0 0 3px #38bdf8)',
                offsetPath: `path("M${props.sourceX},${props.sourceY} C${props.sourceX + 100},${props.sourceY} ${props.targetX - 100},${props.targetY} ${props.targetX},${props.targetY}")`,
                animation: 'electron-flow 3s infinite linear',
                animationDelay: '0.5s'
              }}
            />
            <circle
              r="2.5"
              fill="#fff"
              style={{
                filter: 'drop-shadow(0 0 4px #38bdf8)',
                offsetPath: `path("M${props.sourceX},${props.sourceY} C${props.sourceX + 100},${props.sourceY} ${props.targetX - 100},${props.targetY} ${props.targetX},${props.targetY}")`,
                animation: 'electron-flow 3s infinite linear',
                animationDelay: '1.5s'
              }}
            />
          </>
        )}
      </svg>
    </div>
  );
};

// Initial nodes
const initialNodes = [
  {
    id: 'brain-node',
    type: 'brainNode',
    position: { x: 250, y: 100 },
    data: { 
      label: 'The Brain',
      description: 'Central thought hub',
    },
  },
  {
    id: 'data-processor',
    type: 'processorNode',
    position: { x: 500, y: 250 },
    data: { 
      label: 'Data Processor',
      type: 'Action',
      description: 'Processes and transforms data',
      inputs: [
        { id: '1', name: 'Input Data' },
        { id: '2', name: 'Settings' }
      ],
      outputs: [
        { id: '1', name: 'Result' },
        { id: '2', name: 'Error' }
      ]
    },
  }
];

// Initial edges
const initialEdges = [
  {
    id: 'brain-to-data',
    source: 'brain-node',
    target: 'data-processor',
    animated: true
  }
];

// Define node types
const nodeTypes = {
  brainNode: BrainNode,
  processorNode: ProcessorNode
};

// Main component
const SimpleMindMap = () => {
  // State for nodes and edges
  const [nodes, setNodes] = useState(initialNodes);
  const [edges, setEdges] = useState(initialEdges);
  const [selectedNode, setSelectedNode] = useState(null);
  const [selectedEdge, setSelectedEdge] = useState(null);
  
  // History for undo/redo
  const [history, setHistory] = useState([{ nodes: initialNodes, edges: initialEdges }]);
  const [historyIndex, setHistoryIndex] = useState(0);
  
  // ReactFlow instance
  const reactFlowInstance = useRef(null);
  
  // Handle node changes
  const onNodesChange = useCallback((changes) => {
    setNodes((nds) => {
      const updatedNodes = applyNodeChanges(changes, nds);
      
      // Add to history if needed
      const newHistoryEntry = { nodes: updatedNodes, edges };
      if (JSON.stringify(newHistoryEntry) !== JSON.stringify(history[historyIndex])) {
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(newHistoryEntry);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
      }
      
      return updatedNodes;
    });
  }, [edges, history, historyIndex]);
  
  // Handle edge changes
  const onEdgesChange = useCallback((changes) => {
    setEdges((eds) => {
      const updatedEdges = applyEdgeChanges(changes, eds);
      
      // Add to history if needed
      const newHistoryEntry = { nodes, edges: updatedEdges };
      if (JSON.stringify(newHistoryEntry) !== JSON.stringify(history[historyIndex])) {
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(newHistoryEntry);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
      }
      
      return updatedEdges;
    });
  }, [nodes, history, historyIndex]);
  
  // Handle new connections
  const onConnect = useCallback((params) => {
    setEdges((eds) => {
      const newEdge = {
        ...params,
        id: `edge-${Math.random().toString(36).substring(2, 9)}`,
        animated: true
      };
      
      const updatedEdges = addEdge(newEdge, eds);
      
      // Add to history
      const newHistoryEntry = { nodes, edges: updatedEdges };
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(newHistoryEntry);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
      
      return updatedEdges;
    });
  }, [nodes, history, historyIndex]);
  
  // Handle node selection
  const onNodeClick = useCallback((event, node) => {
    setSelectedNode(node);
    setSelectedEdge(null);
  }, []);
  
  // Handle edge selection
  const onEdgeClick = useCallback((event, edge) => {
    setSelectedEdge(edge);
    setSelectedNode(null);
  }, []);
  
  // Delete selected elements
  const deleteSelected = useCallback(() => {
    if (selectedNode) {
      setNodes((nds) => nds.filter((node) => node.id !== selectedNode.id));
      setEdges((eds) => eds.filter(
        (edge) => edge.source !== selectedNode.id && edge.target !== selectedNode.id
      ));
      setSelectedNode(null);
    } else if (selectedEdge) {
      setEdges((eds) => eds.filter((edge) => edge.id !== selectedEdge.id));
      setSelectedEdge(null);
    }
  }, [selectedNode, selectedEdge]);
  
  // Undo action
  const undo = useCallback(() => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      const { nodes: historyNodes, edges: historyEdges } = history[newIndex];
      
      setNodes(historyNodes);
      setEdges(historyEdges);
      setHistoryIndex(newIndex);
    }
  }, [history, historyIndex]);
  
  // Redo action
  const redo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      const { nodes: historyNodes, edges: historyEdges } = history[newIndex];
      
      setNodes(historyNodes);
      setEdges(historyEdges);
      setHistoryIndex(newIndex);
    }
  }, [history, historyIndex]);
  
  // Store ReactFlow instance
  const onInit = useCallback((instance) => {
    reactFlowInstance.current = instance;
  }, []);
  
  // Zoom controls
  const zoomIn = useCallback(() => {
    if (reactFlowInstance.current) {
      reactFlowInstance.current.zoomIn();
    }
  }, []);
  
  const zoomOut = useCallback(() => {
    if (reactFlowInstance.current) {
      reactFlowInstance.current.zoomOut();
    }
  }, []);
  
  const fitView = useCallback(() => {
    if (reactFlowInstance.current) {
      reactFlowInstance.current.fitView();
    }
  }, []);
  
  return (
    <div className="h-full" style={{ background: '#0f172a' }}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onNodeClick={onNodeClick}
        onEdgeClick={onEdgeClick}
        onInit={onInit}
        nodeTypes={nodeTypes}
        fitView
      >
        <Background variant={BackgroundVariant.Dots} gap={16} color="#334155" />
        <Controls showInteractive={false} />
        
        {/* Toolbar */}
        <Panel position="top-right" className="bg-slate-900/60 p-2 rounded-lg shadow-lg backdrop-blur-sm">
          <div className="flex flex-col gap-1">
            <Button
              variant="ghost"
              size="icon"
              title="Delete selected element"
              onClick={deleteSelected}
              disabled={!selectedNode && !selectedEdge}
              className="text-slate-300 hover:text-red-400"
            >
              <Trash2 size={20} />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              title="Undo"
              onClick={undo}
              disabled={historyIndex <= 0}
              className="text-slate-300 hover:text-blue-300"
            >
              <Undo2 size={20} />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              title="Redo"
              onClick={redo}
              disabled={historyIndex >= history.length - 1}
              className="text-slate-300 hover:text-blue-300"
            >
              <Redo2 size={20} />
            </Button>
          </div>
        </Panel>
        
        {/* Zoom controls */}
        <Panel position="bottom-right" className="bg-slate-900/60 p-2 rounded-lg shadow-lg backdrop-blur-sm">
          <div className="flex flex-col gap-1">
            <Button
              variant="ghost"
              size="icon"
              title="Zoom in"
              onClick={zoomIn}
              className="text-slate-300 hover:text-blue-300"
            >
              <ZoomIn size={20} />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              title="Zoom out"
              onClick={zoomOut}
              className="text-slate-300 hover:text-blue-300"
            >
              <ZoomOut size={20} />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              title="Fit view"
              onClick={fitView}
              className="text-slate-300 hover:text-blue-300"
            >
              <MinusCircle size={20} />
            </Button>
          </div>
        </Panel>
      </ReactFlow>
    </div>
  );
};

// Wrap with provider for proper functioning
const MindMapWrapper = () => {
  return (
    <ReactFlow.ReactFlowProvider>
      <SimpleMindMap />
    </ReactFlow.ReactFlowProvider>
  );
};

export default MindMapWrapper;