import React, { useEffect, useRef, useState } from 'react';
// Mind-elixir import handling with safety checks
let MindElixir;
try {
  MindElixir = require('mind-elixir');
} catch (err) {
  console.error('Failed to load mind-elixir:', err);
  // Create a placeholder if module fails to load
  MindElixir = {
    new: () => ({ 
      root: { topic: 'New Mind Map', children: [] } 
    }),
    SIDE: 1
  };
}
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { 
  Download, 
  Share2, 
  Link, 
  Image, 
  FileText, 
  ChevronDown 
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

const MindElixirComponent = () => {
  const mapRef = useRef(null);
  const mindElixirRef = useRef(null);
  const [isInitialized, setIsInitialized] = useState(false);

  // Initialize the mind map on component mount
  useEffect(() => {
    if (!isInitialized && mapRef.current) {
      const options = {
        el: mapRef.current,
        direction: MindElixir.SIDE,
        data: MindElixir.new('New Mindmap'),
        draggable: true,
        contextMenu: true,
        toolBar: true,
        nodeMenu: true,
        keypress: true,
        contextMenuOption: {
          focus: true,
          link: true,
          extend: [
            {
              name: 'Export as PNG',
              onclick: () => exportAsPng(),
            },
            {
              name: 'Export as SVG',
              onclick: () => exportAsSvg(),
            },
            {
              name: 'Export as Markdown',
              onclick: () => exportAsMarkdown(),
            },
          ],
        },
      };

      mindElixirRef.current = new MindElixir(options);
      mindElixirRef.current.init();

      // Set up event listeners for operations
      mindElixirRef.current.bus.addListener('operation', (operation) => {
        console.log('Mind map operation:', operation);
        
        // Here you could implement persistence with your backend API
        if (operation.name === 'finishEdit' || operation.name === 'editStyle') {
          // Save the node data to your backend
          console.log('Node updated:', operation.obj);
          saveNodeToLocalStorage(mindElixirRef.current.nodeData);
        } else if (operation.name === 'removeNode') {
          // Remove the node from your backend
          console.log('Node removed:', operation.obj.id);
          saveNodeToLocalStorage(mindElixirRef.current.nodeData);
        }
      });

      // We'll load saved data after initialization is complete
      // This avoids potential initialization errors

      setIsInitialized(true);
    }

    // Cleanup function to remove the mind map when component unmounts
    return () => {
      if (mindElixirRef.current) {
        // No explicit destroy method in mind-elixir, but we could clear event listeners
        mindElixirRef.current.bus.removeAllListeners();
      }
    };
  }, [isInitialized]);

  // Helper function to save mind map data to localStorage
  const saveNodeToLocalStorage = (nodeData) => {
    try {
      localStorage.setItem('mindElixirData', JSON.stringify(nodeData));
    } catch (err) {
      console.error('Failed to save mind map data:', err);
    }
  };

  // Export functions
  const exportAsPng = () => {
    if (mindElixirRef.current) {
      // Using the built-in export method
      if (mindElixirRef.current.exportPng) {
        mindElixirRef.current.exportPng('mindmap.png');
      } else {
        // Manual export fallback
        const svg = document.querySelector('#map > svg');
        if (svg) {
          const canvas = document.createElement('canvas');
          const box = svg.getBoundingClientRect();
          canvas.width = box.width;
          canvas.height = box.height;
          const ctx = canvas.getContext('2d');
          
          // Convert SVG to data URL
          const data = new XMLSerializer().serializeToString(svg);
          const img = new Image();
          img.onload = () => {
            ctx.drawImage(img, 0, 0);
            downloadDataURL(canvas.toDataURL('image/png'), 'mindmap.png');
          };
          img.src = 'data:image/svg+xml;base64,' + btoa(data);
        }
      }
      
      toast({
        title: 'Success',
        description: 'Mind map exported as PNG',
      });
    }
  };

  const exportAsSvg = () => {
    if (mindElixirRef.current) {
      // Using the built-in export method
      if (mindElixirRef.current.exportSvg) {
        mindElixirRef.current.exportSvg('mindmap');
      } else {
        // Manual export fallback
        const svg = document.querySelector('#map > svg');
        if (svg) {
          const svgData = new XMLSerializer().serializeToString(svg);
          const svgBlob = new Blob([svgData], {type: 'image/svg+xml;charset=utf-8'});
          const svgUrl = URL.createObjectURL(svgBlob);
          const downloadLink = document.createElement('a');
          downloadLink.href = svgUrl;
          downloadLink.download = 'mindmap.svg';
          document.body.appendChild(downloadLink);
          downloadLink.click();
          document.body.removeChild(downloadLink);
        }
      }
      
      toast({
        title: 'Success',
        description: 'Mind map exported as SVG',
      });
    }
  };
  
  // Helper function to download data URL as file
  const downloadDataURL = (dataURL, filename) => {
    const link = document.createElement('a');
    link.href = dataURL;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportAsMarkdown = () => {
    if (mindElixirRef.current) {
      const markdownContent = mindElixirRef.current.getAllDataMd();
      downloadFile('mindmap.md', markdownContent);
      toast({
        title: 'Success',
        description: 'Mind map exported as Markdown',
      });
    }
  };

  // Helper function to download a file
  const downloadFile = (filename, text) => {
    const element = document.createElement('a');
    element.setAttribute(
      'href',
      'data:text/plain;charset=utf-8,' + encodeURIComponent(text)
    );
    element.setAttribute('download', filename);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="bg-slate-900/60 p-2 rounded-md shadow-lg backdrop-blur-sm mb-2">
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Download size={16} />
                Export
                <ChevronDown size={16} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={exportAsPng}>
                <Image size={16} className="mr-2" />
                Export as PNG
              </DropdownMenuItem>
              <DropdownMenuItem onClick={exportAsSvg}>
                <Image size={16} className="mr-2" />
                Export as SVG
              </DropdownMenuItem>
              <DropdownMenuItem onClick={exportAsMarkdown}>
                <FileText size={16} className="mr-2" />
                Export as Markdown
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button variant="outline" className="gap-2">
            <Share2 size={16} />
            Share
          </Button>

          <Button variant="outline" className="gap-2">
            <Link size={16} />
            Add Hyperlink
          </Button>
        </div>
      </div>

      <div
        ref={mapRef}
        className="flex-1 rounded-md overflow-hidden"
        style={{ height: 'calc(100vh - 120px)', width: '100%' }}
      />
    </div>
  );
};

export default MindElixirComponent;