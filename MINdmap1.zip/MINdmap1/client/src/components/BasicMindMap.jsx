import React, { useState, useCallback } from 'react';
import ReactFlow, {
  ReactFlowProvider,
  Background,
  Controls,
  Panel,
  applyNodeChanges,
  applyEdgeChanges,
  addEdge
} from 'reactflow';
import 'reactflow/dist/style.css';
import { ZoomIn, ZoomOut, Undo2, Redo2, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

// Custom nodes
const BrainNode = ({ data, selected }) => (
  <div 
    style={{
      padding: '15px',
      borderRadius: '12px',
      background: 'rgba(59, 130, 246, 0.2)',
      backdropFilter: 'blur(8px)',
      border: '1px solid rgba(255, 255, 255, 0.2)',
      boxShadow: selected ? '0 0 15px rgba(59, 130, 246, 0.5)' : '0 8px 32px rgba(14, 165, 233, 0.15)',
      minWidth: '150px',
      minHeight: '150px',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      color: '#e2e8f0',
      textAlign: 'center',
      transform: selected ? 'scale(1.05)' : 'scale(1)',
      transition: 'all 0.3s ease'
    }}
  >
    <div style={{ fontWeight: 'bold', fontSize: '1.25rem', marginBottom: '8px', color: '#f8fafc' }}>
      {data.label}
    </div>
    
    {data.description && (
      <div style={{ fontSize: '0.875rem', color: '#cbd5e1' }}>
        {data.description}
      </div>
    )}
    
    <div 
      style={{
        width: '60px',
        height: '60px',
        background: 'radial-gradient(circle, rgba(56, 189, 248, 0.8) 0%, rgba(59, 130, 246, 0.4) 70%)',
        borderRadius: '50%',
        margin: '12px auto',
        animation: 'pulse 2s infinite',
        boxShadow: '0 0 15px rgba(56, 189, 248, 0.6)',
        position: 'relative'
      }}
    >
      <div 
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '30px',
          height: '30px',
          background: 'rgba(255, 255, 255, 0.8)',
          borderRadius: '50%',
          boxShadow: '0 0 10px rgba(255, 255, 255, 0.8)'
        }}
      />
    </div>
  </div>
);

const ProcessorNode = ({ data, selected }) => (
  <div 
    style={{
      padding: '12px',
      borderRadius: '8px',
      background: 'rgba(79, 70, 229, 0.2)',
      backdropFilter: 'blur(8px)',
      border: '1px solid rgba(255, 255, 255, 0.2)',
      boxShadow: selected ? '0 0 15px rgba(79, 70, 229, 0.5)' : '0 8px 32px rgba(79, 70, 229, 0.15)',
      minWidth: '180px',
      color: '#e2e8f0',
      transform: selected ? 'scale(1.05)' : 'scale(1)',
      transition: 'all 0.3s ease'
    }}
  >
    <div style={{ fontWeight: 'bold', fontSize: '1rem', marginBottom: '4px', color: '#f8fafc' }}>
      {data.label}
    </div>
    
    <div 
      style={{
        display: 'inline-block',
        fontSize: '0.75rem',
        padding: '2px 8px',
        borderRadius: '4px',
        background: 'rgba(79, 70, 229, 0.4)',
        marginBottom: '8px'
      }}
    >
      {data.type || 'Processor'}
    </div>
    
    {data.description && (
      <div 
        style={{
          fontSize: '0.875rem',
          color: '#cbd5e1',
          marginBottom: '8px',
          borderTop: '1px solid rgba(255, 255, 255, 0.1)',
          paddingTop: '8px'
        }}
      >
        {data.description}
      </div>
    )}
    
    <div style={{ display: 'flex' }}>
      <div style={{ flex: 1, borderRight: '1px solid rgba(255, 255, 255, 0.1)' }}>
        <div style={{ fontSize: '0.75rem', opacity: 0.7, marginBottom: '4px' }}>Inputs</div>
        {data.inputs && data.inputs.map((input, index) => (
          <div 
            key={index}
            style={{
              fontSize: '0.8rem',
              padding: '4px',
              borderRadius: '4px',
              background: 'rgba(255, 255, 255, 0.05)',
              marginBottom: '4px'
            }}
          >
            {input.name}
          </div>
        ))}
      </div>
      
      <div style={{ flex: 1, paddingLeft: '8px' }}>
        <div style={{ fontSize: '0.75rem', opacity: 0.7, marginBottom: '4px' }}>Outputs</div>
        {data.outputs && data.outputs.map((output, index) => (
          <div 
            key={index}
            style={{
              fontSize: '0.8rem',
              padding: '4px',
              borderRadius: '4px',
              background: 'rgba(255, 255, 255, 0.05)',
              marginBottom: '4px',
              textAlign: 'right'
            }}
          >
            {output.name}
          </div>
        ))}
      </div>
    </div>
  </div>
);

// Initial nodes
const initialNodes = [
  {
    id: 'brain-node',
    type: 'brainNode',
    position: { x: 250, y: 100 },
    data: { 
      label: 'The Brain',
      description: 'Central thought hub',
    },
  },
  {
    id: 'data-processor',
    type: 'processorNode',
    position: { x: 500, y: 250 },
    data: { 
      label: 'Data Processor',
      type: 'Action',
      description: 'Processes and transforms data',
      inputs: [
        { id: '1', name: 'Input Data' },
        { id: '2', name: 'Settings' }
      ],
      outputs: [
        { id: '1', name: 'Result' },
        { id: '2', name: 'Error' }
      ]
    },
  }
];

// Initial edges
const initialEdges = [
  {
    id: 'brain-to-data',
    source: 'brain-node',
    target: 'data-processor',
    animated: true,
    style: { stroke: '#38bdf8', strokeWidth: 2 }
  }
];

// Define node types
const nodeTypes = {
  brainNode: BrainNode,
  processorNode: ProcessorNode
};

// Main component
function Flow() {
  const [nodes, setNodes] = useState(initialNodes);
  const [edges, setEdges] = useState(initialEdges);
  
  const [selectedElements, setSelectedElements] = useState([]);
  const [reactFlowInstance, setReactFlowInstance] = useState(null);
  
  // Basic undo/redo support
  const [history, setHistory] = useState([{ nodes: initialNodes, edges: initialEdges }]);
  const [historyIndex, setHistoryIndex] = useState(0);
  
  const onNodesChange = useCallback(
    (changes) => {
      setNodes((nds) => {
        const newNodes = applyNodeChanges(changes, nds);
        
        // Add to history if needed
        const newState = { nodes: newNodes, edges };
        if (JSON.stringify(newState) !== JSON.stringify(history[historyIndex])) {
          const newHistory = history.slice(0, historyIndex + 1);
          newHistory.push(newState);
          setHistory(newHistory);
          setHistoryIndex(newHistory.length - 1);
        }
        
        return newNodes;
      });
    },
    [edges, history, historyIndex]
  );
  
  const onEdgesChange = useCallback(
    (changes) => {
      setEdges((eds) => {
        const newEdges = applyEdgeChanges(changes, eds);
        
        // Add to history if needed
        const newState = { nodes, edges: newEdges };
        if (JSON.stringify(newState) !== JSON.stringify(history[historyIndex])) {
          const newHistory = history.slice(0, historyIndex + 1);
          newHistory.push(newState);
          setHistory(newHistory);
          setHistoryIndex(newHistory.length - 1);
        }
        
        return newEdges;
      });
    },
    [nodes, history, historyIndex]
  );
  
  const onConnect = useCallback(
    (params) => {
      setEdges((eds) => {
        const newEdge = {
          ...params,
          id: `edge-${Math.random().toString(36).substring(2, 9)}`,
          animated: true,
          style: { stroke: '#38bdf8', strokeWidth: 2 }
        };
        
        const newEdges = addEdge(newEdge, eds);
        
        // Add to history
        const newState = { nodes, edges: newEdges };
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(newState);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
        
        return newEdges;
      });
    },
    [nodes, history, historyIndex]
  );
  
  const onInit = useCallback((instance) => {
    setReactFlowInstance(instance);
  }, []);
  
  const onSelectionChange = useCallback((elements) => {
    setSelectedElements(elements);
  }, []);
  
  // Delete selected elements
  const onDeleteSelected = useCallback(() => {
    if (selectedElements.nodes && selectedElements.nodes.length > 0) {
      const selectedNodeIds = selectedElements.nodes.map((node) => node.id);
      
      setNodes((nds) => nds.filter((node) => !selectedNodeIds.includes(node.id)));
      setEdges((eds) =>
        eds.filter(
          (edge) => !selectedNodeIds.includes(edge.source) && !selectedNodeIds.includes(edge.target)
        )
      );
    }
    
    if (selectedElements.edges && selectedElements.edges.length > 0) {
      const selectedEdgeIds = selectedElements.edges.map((edge) => edge.id);
      setEdges((eds) => eds.filter((edge) => !selectedEdgeIds.includes(edge.id)));
    }
  }, [selectedElements]);
  
  // Undo action
  const onUndo = useCallback(() => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      const { nodes: historyNodes, edges: historyEdges } = history[newIndex];
      
      setNodes(historyNodes);
      setEdges(historyEdges);
      setHistoryIndex(newIndex);
    }
  }, [history, historyIndex]);
  
  // Redo action
  const onRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      const { nodes: historyNodes, edges: historyEdges } = history[newIndex];
      
      setNodes(historyNodes);
      setEdges(historyEdges);
      setHistoryIndex(newIndex);
    }
  }, [history, historyIndex]);
  
  // Zoom controls
  const onZoomIn = useCallback(() => {
    if (reactFlowInstance) {
      reactFlowInstance.zoomIn();
    }
  }, [reactFlowInstance]);
  
  const onZoomOut = useCallback(() => {
    if (reactFlowInstance) {
      reactFlowInstance.zoomOut();
    }
  }, [reactFlowInstance]);
  
  return (
    <ReactFlow
      nodes={nodes}
      edges={edges}
      onNodesChange={onNodesChange}
      onEdgesChange={onEdgesChange}
      onConnect={onConnect}
      onInit={onInit}
      onSelectionChange={onSelectionChange}
      nodeTypes={nodeTypes}
      defaultViewport={{ x: 0, y: 0, zoom: 1 }}
      minZoom={0.2}
      maxZoom={4}
      fitView
      attributionPosition="bottom-right"
    >
      <Background color="#334155" gap={16} size={1} />
      <Controls />
      
      {/* Toolbar */}
      <Panel position="top-right" className="bg-slate-900/60 p-2 rounded-lg shadow-lg backdrop-blur-sm">
        <div className="flex flex-col gap-1">
          <Button
            variant="ghost"
            size="icon"
            title="Delete selected elements"
            onClick={onDeleteSelected}
            disabled={!selectedElements || ((!selectedElements.nodes || selectedElements.nodes.length === 0) && (!selectedElements.edges || selectedElements.edges.length === 0))}
            className="text-slate-300 hover:text-red-400"
          >
            <Trash2 size={20} />
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            title="Undo"
            onClick={onUndo}
            disabled={historyIndex <= 0}
            className="text-slate-300 hover:text-blue-300"
          >
            <Undo2 size={20} />
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            title="Redo"
            onClick={onRedo}
            disabled={historyIndex >= history.length - 1}
            className="text-slate-300 hover:text-blue-300"
          >
            <Redo2 size={20} />
          </Button>
        </div>
      </Panel>
      
      {/* Zoom controls */}
      <Panel position="bottom-right" className="bg-slate-900/60 p-2 rounded-lg shadow-lg backdrop-blur-sm">
        <div className="flex flex-col gap-1">
          <Button
            variant="ghost"
            size="icon"
            title="Zoom in"
            onClick={onZoomIn}
            className="text-slate-300 hover:text-blue-300"
          >
            <ZoomIn size={20} />
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            title="Zoom out"
            onClick={onZoomOut}
            className="text-slate-300 hover:text-blue-300"
          >
            <ZoomOut size={20} />
          </Button>
        </div>
      </Panel>
    </ReactFlow>
  );
}

// Wrap with provider for proper functioning
export default function BasicMindMap() {
  return (
    <ReactFlowProvider>
      <div style={{ width: '100%', height: '100%', background: '#0f172a' }}>
        <Flow />
      </div>
    </ReactFlowProvider>
  );
}