import React, { useState } from 'react';
import {
  Sliders,
  X,
  Info,
  Type,
  Palette,
  Box,
  ArrowUpDown,
  Save,
  Trash2,
  Unlink,
  Plus
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

// Properties Panel Component
const PropertiesPanel = ({ 
  isOpen, 
  onToggle, 
  selectedNode, 
  selectedEdge,
  onUpdateNodeData,
  onUpdateNodeStyle,
  onUpdateEdgeStyle
}) => {
  const [activeTab, setActiveTab] = useState("general");

  // Form values (dynamically updated based on selected element)
  const [values, setValues] = useState({});

  // Update form values when selection changes
  React.useEffect(() => {
    if (selectedNode) {
      setValues({
        label: selectedNode.data.label || '',
        description: selectedNode.data.description || '',
        type: selectedNode.data.type || '',
        color: selectedNode.data.color || getColorFromType(selectedNode.data.type),
        backgroundColor: selectedNode.style?.background || '',
        borderColor: selectedNode.style?.borderColor || '',
        fontSize: selectedNode.style?.fontSize || '1rem',
        width: selectedNode.width || 'auto',
        height: selectedNode.height || 'auto',
        // Make sure subnodes are included for database nodes
        subnodes: selectedNode.type === 'databaseNode' ? 
          (selectedNode.data.subnodes ? [...selectedNode.data.subnodes] : []) : 
          undefined
      });
      setActiveTab("general");
    } else if (selectedEdge) {
      setValues({
        animated: selectedEdge.animated || false,
        strokeWidth: selectedEdge.style?.strokeWidth || 2,
        strokeColor: selectedEdge.style?.stroke || '#38bdf8',
        dashArray: selectedEdge.style?.strokeDasharray || ''
      });
      setActiveTab("style");
    } else {
      setValues({});
    }
  }, [selectedNode, selectedEdge]);

  // Handle input changes
  const handleChange = (field, value) => {
    setValues(prev => ({ ...prev, [field]: value }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();

    if (selectedNode) {
      // Update node data
      const nodeData = {
        label: values.label,
        description: values.description,
        type: values.type,
        color: values.color
      };

      // Update node style
      const nodeStyle = {
        background: values.backgroundColor,
        borderColor: values.borderColor,
        fontSize: values.fontSize
      };

      // Call parent update functions
      onUpdateNodeData(selectedNode.id, nodeData);
      onUpdateNodeStyle(selectedNode.id, nodeStyle);
    } else if (selectedEdge) {
      // Update edge style
      const edgeStyle = {
        strokeWidth: values.strokeWidth,
        stroke: values.strokeColor,
        strokeDasharray: values.dashArray
      };

      // Update animated property
      onUpdateEdgeStyle(selectedEdge.id, edgeStyle, values.animated);
    }
  };

  // Handle edge deletion
  const handleDeleteEdge = () => {
    if (selectedEdge) {
      // Call the parent deletion function
      onUpdateEdgeStyle(selectedEdge.id, { delete: true });
    }
  };

  // Helper function to get color from node type
  const getColorFromType = (type) => {
    const typeColors = {
      'action': '#3b82f6',    // blue
      'trigger': '#ef4444',   // red
      'helper': '#10b981',    // green
      'transformer': '#8b5cf6', // purple
      'api': '#06b6d4',       // cyan
      'prompt': '#ea580c',    // orange
      'start': '#38bdf8',     // light blue
      'brainNode': '#60a5fa'  // For the brain node
    };

    return typeColors[type] || '#3b82f6';
  };

  // If no element is selected
  if (!selectedNode && !selectedEdge) {
    return (
      <div 
        className={`properties-panel ${isOpen ? 'open' : 'closed'}`}
        style={{
          position: 'absolute',
          top: '0',
          right: '0',
          height: '100%',
          width: isOpen ? '300px' : '0',
          background: 'rgba(15, 23, 42, 0.85)',
          backdropFilter: 'blur(10px)',
          borderLeft: '1px solid rgba(255, 255, 255, 0.1)',
          transition: 'width 0.3s ease',
          zIndex: 10,
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        <div className="properties-header p-4 flex justify-between items-center border-b border-slate-700/50">
          <h3 className="text-lg font-semibold text-slate-200">Properties</h3>
          <Button variant="ghost" size="sm" onClick={onToggle} className="text-slate-400 hover:text-slate-200">
            <X size={18} />
          </Button>
        </div>

        <div className="properties-content p-6 flex-1 flex items-center justify-center">
          <div className="text-center text-slate-400">
            <Info size={40} className="mx-auto mb-2 opacity-40" />
            <p>Select a node or edge to view and edit its properties</p>
          </div>
        </div>

        <button
          className="properties-toggle absolute -left-4 top-1/2 transform -translate-y-1/2 bg-slate-800 border border-slate-700 rounded-full w-8 h-8 flex items-center justify-center"
          onClick={onToggle}
          title={isOpen ? "Close sidebar" : "Open sidebar"}
        >
          {isOpen ? 
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300">
              <path d="M9 18l6-6-6-6" />
            </svg>
            :
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300">
              <path d="M15 18l-6-6 6-6" />
            </svg>
          }
        </button>
      </div>
    );
  }

  return (
    <div 
      className={`properties-panel ${isOpen ? 'open' : 'closed'}`}
      style={{
        position: 'absolute',
        top: '0',
        right: '0',
        height: '100%',
        width: isOpen ? '300px' : '0',
        background: 'rgba(15, 23, 42, 0.85)',
        backdropFilter: 'blur(10px)',
        borderLeft: '1px solid rgba(255, 255, 255, 0.1)',
        transition: 'width 0.3s ease',
        zIndex: 10,
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      <div className="properties-header p-4 flex justify-between items-center border-b border-slate-700/50">
        <h3 className="text-lg font-semibold text-slate-200">
          {selectedNode ? 'Node Properties' : 'Edge Properties'}
        </h3>
        <Button variant="ghost" size="sm" onClick={onToggle} className="text-slate-400 hover:text-slate-200">
          <X size={18} />
        </Button>
      </div>

      <div className="properties-content flex-1 overflow-y-auto p-4">
        <form onSubmit={handleSubmit}>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full grid grid-cols-3 mb-6">
              <TabsTrigger value="general" disabled={!selectedNode}>General</TabsTrigger>
              <TabsTrigger value="style">Style</TabsTrigger>
              <TabsTrigger value="advanced">Advanced</TabsTrigger>
            </TabsList>

            {selectedNode && (
              <TabsContent value="general" className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="label">Label</Label>
                  <Input
                    id="label"
                    value={values.label || ''}
                    onChange={(e) => handleChange('label', e.target.value)}
                    placeholder="Node label"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={values.description || ''}
                    onChange={(e) => handleChange('description', e.target.value)}
                    placeholder="Node description"
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="type">Type</Label>
                  <Input
                    id="type"
                    value={values.type || ''}
                    onChange={(e) => handleChange('type', e.target.value)}
                    placeholder="Node type"
                  />
                </div>

                {/* Special controls for Database Node */}
                {selectedNode.type === 'databaseNode' && (
                  <div className="mt-6 pt-4 border-t border-slate-700/50">
                    {/* Title section with node name and type */}
                    <div className="flex flex-col gap-3 mb-4">
                      <div className="flex gap-2">
                        <Input
                          value={values.label || ''}
                          onChange={(e) => handleChange('label', e.target.value)}
                          className="flex-1 bg-slate-800/80"
                          placeholder="Node name"
                        />
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <h4 className="text-sm font-medium text-purple-400">Database Rows</h4>
                        
                        <Button
                          type="button"
                          className="bg-indigo-700 hover:bg-indigo-600 text-white text-xs py-1 px-2 h-8"
                          onClick={() => {
                            // Add a database section with a pair of handles (one input, one output)
                            const currentSubnodes = values.subnodes || [];
                            const rowCount = Math.floor(currentSubnodes.length/2) + 1;
                            const extendedSubnodes = [
                              ...currentSubnodes,
                              { 
                                label: `Input ${rowCount}`,
                                type: 'input',
                                direction: 'input',
                                category: 'db-row',
                                rowId: `row-${rowCount}`
                              },
                              {
                                label: `Output ${rowCount}`, 
                                type: 'output',
                                direction: 'output',
                                rowId: `row-${rowCount}`
                              }
                            ];
                            handleChange('subnodes', extendedSubnodes);
                          }}
                        >
                          <Plus className="mr-1 h-3 w-3" />
                          Extend Node
                        </Button>
                      </div>
                    </div>

                    {/* Database rows editor organized as pairs */}
                    {values.subnodes && values.subnodes.length > 0 ? (
                      <div className="space-y-3 mb-4">
                        {(() => {
                          // Get all unique rowIds
                          const rowIds = Array.from(new Set(
                            values.subnodes
                              .filter(node => node.rowId)
                              .map(node => node.rowId)
                          ));
                          
                          return rowIds.map((rowId, rowIndex) => {
                            const inputNodes = values.subnodes.filter(
                              node => node.rowId === rowId && 
                                    (node.direction === 'input' || node.type === 'input')
                            );
                            
                            const outputNodes = values.subnodes.filter(
                              node => node.rowId === rowId && 
                                    (node.direction === 'output' || node.type === 'output')
                            );
                            
                            const inputNode = inputNodes.length > 0 ? inputNodes[0] : null;
                            const outputNode = outputNodes.length > 0 ? outputNodes[0] : null;
                            
                            if (!inputNode && !outputNode) return null;
                            
                            const inputIndex = values.subnodes.findIndex(n => n === inputNode);
                            const outputIndex = values.subnodes.findIndex(n => n === outputNode);
                            
                            return (
                              <div 
                                key={rowId}
                                className="p-3 bg-slate-800/50 rounded-md border border-slate-700/50"
                              >
                                <div className="flex justify-between items-center mb-2">
                                  <h5 className="text-sm font-medium text-slate-300">Row {rowIndex + 1}</h5>
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="sm"
                                    className="h-7 w-7 p-0 text-red-400 hover:text-red-300"
                                    onClick={() => {
                                      // Remove all nodes with this rowId
                                      const newSubnodes = values.subnodes.filter(n => n.rowId !== rowId);
                                      handleChange('subnodes', newSubnodes);
                                    }}
                                  >
                                    <X size={14} />
                                  </Button>
                                </div>
                                
                                <div className="grid grid-cols-2 gap-3">
                                  {/* Input side */}
                                  {inputNode && (
                                    <div className="space-y-1">
                                      <div className="flex items-center">
                                        <div className="w-3 h-3 rounded-full mr-2 bg-blue-500"></div>
                                        <Label className="text-xs text-blue-300">Input</Label>
                                      </div>
                                      <Input
                                        value={inputNode.label || ''}
                                        onChange={(e) => {
                                          // Create a deep copy to ensure reactivity
                                          const newSubnodes = JSON.parse(JSON.stringify(values.subnodes));
                                          // Update the specific node
                                          newSubnodes[inputIndex] = {
                                            ...newSubnodes[inputIndex],
                                            label: e.target.value
                                          };
                                          // Apply the change immediately to the form state
                                          handleChange('subnodes', newSubnodes);
                                          
                                          // Also update the actual node in real-time
                                          if (selectedNode) {
                                            const updatedNodeData = {
                                              ...selectedNode.data,
                                              subnodes: newSubnodes
                                            };
                                            onUpdateNodeData(selectedNode.id, updatedNodeData);
                                          }
                                        }}
                                        className="h-8 text-xs"
                                        placeholder="Input name"
                                      />
                                    </div>
                                  )}
                                  
                                  {/* Output side */}
                                  {outputNode && (
                                    <div className="space-y-1">
                                      <div className="flex items-center justify-end">
                                        <Label className="text-xs text-green-300">Output</Label>
                                        <div className="w-3 h-3 rounded-full ml-2 bg-green-500"></div>
                                      </div>
                                      <Input
                                        value={outputNode.label || ''}
                                        onChange={(e) => {
                                          // Create a deep copy to ensure reactivity
                                          const newSubnodes = JSON.parse(JSON.stringify(values.subnodes));
                                          // Update the specific node
                                          newSubnodes[outputIndex] = {
                                            ...newSubnodes[outputIndex],
                                            label: e.target.value
                                          };
                                          // Apply the change immediately to the form state
                                          handleChange('subnodes', newSubnodes);
                                          
                                          // Also update the actual node in real-time
                                          if (selectedNode) {
                                            const updatedNodeData = {
                                              ...selectedNode.data,
                                              subnodes: newSubnodes
                                            };
                                            onUpdateNodeData(selectedNode.id, updatedNodeData);
                                          }
                                        }}
                                        className="h-8 text-xs"
                                        placeholder="Output name"
                                      />
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          });
                        })()}
                      </div>
                    ) : (
                      <div className="text-center text-slate-400 py-3 mb-3">
                        <p>No rows added yet</p>
                      </div>
                    )}
                    
                    {/* Database Files section */}
                    <div className="mt-4 border-t border-slate-700/50 pt-4">
                      <h4 className="text-sm font-medium text-purple-400 mb-3">Database Files</h4>
                      <div className="space-y-2">
                        <div className="bg-slate-800/50 p-3 rounded-md flex justify-between items-center">
                          <div className="flex items-center">
                            <Box className="h-4 w-4 mr-2 text-blue-400" />
                            <span className="text-sm">users.json</span>
                          </div>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="h-7 px-2 text-slate-400 hover:text-slate-300"
                          >
                            <Info size={14} className="mr-1" />
                            View
                          </Button>
                        </div>
                        
                        <Button
                          type="button"
                          className="w-full bg-slate-700 hover:bg-slate-600 mt-2"
                        >
                          <Plus className="mr-2 h-4 w-4" />
                          Upload Database File
                        </Button>
                      </div>
                    </div>

                    {/* Input/Output buttons */}
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        className="flex-1 bg-blue-700 hover:bg-blue-600 text-white"
                        onClick={() => {
                          const currentSubnodes = values.subnodes || [];
                          handleChange('subnodes', [
                            ...currentSubnodes,
                            { 
                              label: `Input ${currentSubnodes.filter(n => n.direction === 'input').length + 1}`,
                              type: 'input',
                              direction: 'input',
                              category: 'default'
                            }
                          ]);
                        }}
                      >
                        <Plus className="mr-2 h-4 w-4" />
                        Add Input
                      </Button>
                      
                      <Button
                        type="button"
                        className="flex-1 bg-green-700 hover:bg-green-600 text-white"
                        onClick={() => {
                          const currentSubnodes = values.subnodes || [];
                          handleChange('subnodes', [
                            ...currentSubnodes,
                            { 
                              label: `Output ${currentSubnodes.filter(n => n.direction === 'output').length + 1}`,
                              type: 'output',
                              direction: 'output'
                            }
                          ]);
                        }}
                      >
                        <Plus className="mr-2 h-4 w-4" />
                        Add Output
                      </Button>
                    </div>
                  </div>
                )}
              </TabsContent>
            )}

            <TabsContent value="style" className="space-y-4">
              {selectedNode && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="color">Color</Label>
                    <div className="flex space-x-2">
                      <div 
                        className="w-10 h-10 rounded border border-slate-600"
                        style={{ backgroundColor: values.color || '#3b82f6' }}
                      />
                      <Input
                        id="color"
                        type="text"
                        value={values.color || ''}
                        onChange={(e) => handleChange('color', e.target.value)}
                        placeholder="#RRGGBB"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="backgroundColor">Background</Label>
                    <Input
                      id="backgroundColor"
                      value={values.backgroundColor || ''}
                      onChange={(e) => handleChange('backgroundColor', e.target.value)}
                      placeholder="Background color/gradient"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="fontSize">Font Size</Label>
                    <Input
                      id="fontSize"
                      value={values.fontSize || ''}
                      onChange={(e) => handleChange('fontSize', e.target.value)}
                      placeholder="Font size (e.g., 1rem)"
                    />
                  </div>
                </>
              )}

              {selectedEdge && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="animated">Animated</Label>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="animated"
                        checked={values.animated || false}
                        onCheckedChange={(checked) => handleChange('animated', checked)}
                      />
                      <span className="text-sm text-slate-300">
                        {values.animated ? 'Enabled' : 'Disabled'}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="strokeColor">Line Color</Label>
                    <div className="flex space-x-2">
                      <div 
                        className="w-10 h-10 rounded border border-slate-600"
                        style={{ backgroundColor: values.strokeColor || '#38bdf8' }}
                      />
                      <Input
                        id="strokeColor"
                        value={values.strokeColor || ''}
                        onChange={(e) => handleChange('strokeColor', e.target.value)}
                        placeholder="#RRGGBB"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="strokeWidth">Line Width</Label>
                    <Input
                      id="strokeWidth"
                      type="number"
                      min="1"
                      max="10"
                      value={values.strokeWidth || 2}
                      onChange={(e) => handleChange('strokeWidth', Number(e.target.value))}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="dashArray">Dash Pattern</Label>
                    <Input
                      id="dashArray"
                      value={values.dashArray || ''}
                      onChange={(e) => handleChange('dashArray', e.target.value)}
                      placeholder="e.g., 5,5 (solid if empty)"
                    />
                  </div>
                </>
              )}
            </TabsContent>

            <TabsContent value="advanced" className="space-y-4">
              {selectedNode && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="width">Width</Label>
                    <Input
                      id="width"
                      value={values.width || ''}
                      onChange={(e) => handleChange('width', e.target.value)}
                      placeholder="Width (e.g., 200px, auto)"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="height">Height</Label>
                    <Input
                      id="height"
                      value={values.height || ''}
                      onChange={(e) => handleChange('height', e.target.value)}
                      placeholder="Height (e.g., 100px, auto)"
                    />
                  </div>
                </>
              )}

              {selectedEdge && (
                <div className="space-y-4">
                  <div className="flex flex-col p-4 border border-slate-300/30 bg-white/90 backdrop-blur-lg rounded-md text-slate-800">
                    <h4 className="text-sm font-medium text-blue-700 mb-2">Connection Information</h4>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="text-slate-700 font-medium">Source:</div>
                      <div className="text-slate-900">{selectedEdge.source}</div>

                      <div className="text-slate-700 font-medium">Source Handle:</div>
                      <div className="text-slate-900">{selectedEdge.sourceHandle || 'Default'}</div>

                      <div className="text-slate-700 font-medium">Target:</div>
                      <div className="text-slate-900">{selectedEdge.target}</div>

                      <div className="text-slate-700 font-medium">Target Handle:</div>
                      <div className="text-slate-900">{selectedEdge.targetHandle || 'Default'}</div>
                    </div>

                    <div className="mt-4">
                      <Button
                        type="button"
                        variant="destructive"
                        className="w-full bg-red-700 hover:bg-red-800 text-white"
                        onClick={handleDeleteEdge}
                      >
                        <Unlink className="mr-2 h-4 w-4" />
                        Delete Connection
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>

          <div className="mt-6 flex justify-end">
            <Button 
              type="button" 
              className="bg-blue-600 hover:bg-blue-700"
              onClick={() => {
                // Apply all changes to the node
                const updatedNode = {
                  ...selectedNode,
                  data: {
                    ...selectedNode.data,
                    ...values
                  }
                };
                
                // Also add a row automatically for database nodes
                if (selectedNode?.type === 'databaseNode') {
                  const currentSubnodes = values.subnodes || [];
                  const rowCount = Math.floor(currentSubnodes.length/2) + 1;
                  
                  const extendedSubnodes = [
                    ...currentSubnodes,
                    { 
                      label: `Input ${rowCount}`,
                      type: 'input',
                      direction: 'input',
                      category: 'db-row',
                      rowId: `row-${rowCount}`
                    },
                    {
                      label: `Output ${rowCount}`, 
                      type: 'output',
                      direction: 'output',
                      rowId: `row-${rowCount}`
                    }
                  ];
                  
                  updatedNode.data.subnodes = extendedSubnodes;
                  // Update form values to reflect the new subnodes
                  handleChange('subnodes', extendedSubnodes);
                }
                
                // Send the updated node to parent component
                onUpdateNodeData(selectedNode.id, updatedNode.data);
              }}
            >
              <Save className="mr-2 h-4 w-4" />
              Apply Changes
            </Button>
          </div>
        </form>
      </div>

      <button
        className="properties-toggle absolute -left-4 top-1/2 transform -translate-y-1/2 bg-slate-800 border border-slate-700 rounded-full w-8 h-8 flex items-center justify-center"
        onClick={onToggle}
        title={isOpen ? "Close sidebar" : "Open sidebar"}
      >
        {isOpen ? 
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300">
            <path d="M9 18l6-6-6-6" />
          </svg>
          :
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300">
            <path d="M15 18l-6-6 6-6" />
          </svg>
        }
      </button>
    </div>
  );
};

export default PropertiesPanel;