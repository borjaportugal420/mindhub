import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { 
  PlusCircle, 
  Download, 
  Share2, 
  Trash2, 
  ZoomIn, 
  ZoomOut 
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

// Default mind map data
const DEFAULT_MIND_MAP = {
  id: 'root',
  text: 'New Mind Map',
  children: [
    { id: 'child1', text: 'Topic 1', children: [] },
    { id: 'child2', text: 'Topic 2', children: [] },
    { id: 'child3', text: 'Topic 3', children: [] },
  ]
};

const SimpleMindMap = () => {
  const [mindMap, setMindMap] = useState(DEFAULT_MIND_MAP);
  const [zoom, setZoom] = useState(1);
  const [selectedNode, setSelectedNode] = useState(null);
  const [newNodeText, setNewNodeText] = useState('');
  const mapContainerRef = useRef(null);
  
  // Load saved mind map from localStorage on component mount
  useEffect(() => {
    try {
      const savedMap = localStorage.getItem('simpleMindMap');
      if (savedMap) {
        setMindMap(JSON.parse(savedMap));
      }
    } catch (err) {
      console.error('Failed to load saved mind map:', err);
    }
  }, []);
  
  // Save mind map to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem('simpleMindMap', JSON.stringify(mindMap));
    } catch (err) {
      console.error('Failed to save mind map:', err);
    }
  }, [mindMap]);
  
  // Function to find a node by ID in the mind map tree
  const findNodeById = (tree, id) => {
    if (tree.id === id) {
      return tree;
    }
    
    if (tree.children) {
      for (const child of tree.children) {
        const found = findNodeById(child, id);
        if (found) return found;
      }
    }
    
    return null;
  };
  
  // Function to add a child node to a parent node
  const addChildNode = () => {
    if (!selectedNode || !newNodeText.trim()) return;
    
    const newNode = {
      id: `node_${Date.now()}`,
      text: newNodeText.trim(),
      children: []
    };
    
    const addChildToNode = (tree) => {
      if (tree.id === selectedNode) {
        return {
          ...tree,
          children: [...tree.children, newNode]
        };
      }
      
      if (tree.children) {
        return {
          ...tree,
          children: tree.children.map(child => addChildToNode(child))
        };
      }
      
      return tree;
    };
    
    setMindMap(addChildToNode(mindMap));
    setNewNodeText('');
    
    toast({
      title: 'Node Added',
      description: `Added new node: ${newNodeText}`,
    });
  };
  
  // Function to delete a node from the mind map
  const deleteNode = (nodeId) => {
    if (!nodeId || nodeId === 'root') return; // Prevent deleting the root node
    
    const deleteNodeFromTree = (tree) => {
      if (tree.children) {
        return {
          ...tree,
          children: tree.children
            .filter(child => child.id !== nodeId)
            .map(child => deleteNodeFromTree(child))
        };
      }
      
      return tree;
    };
    
    setMindMap(deleteNodeFromTree(mindMap));
    if (selectedNode === nodeId) {
      setSelectedNode(null);
    }
    
    toast({
      title: 'Node Deleted',
      description: 'Node and all its children have been removed',
    });
  };
  
  // Function to render a node and its children recursively
  const renderNode = (node, level = 0, parentX = 0, parentY = 0) => {
    const isRoot = node.id === 'root';
    const isSelected = node.id === selectedNode;
    const x = isRoot ? 50 : parentX + 180;
    const y = isRoot ? 250 : parentY;
    
    // Calculate vertical positioning for children
    const childCount = node.children.length;
    const childHeight = 80;
    const totalChildrenHeight = childCount * childHeight;
    let startY = y - totalChildrenHeight / 2 + childHeight / 2;
    
    return (
      <g key={node.id} transform={`scale(${zoom})`}>
        {/* Connection line to parent */}
        {!isRoot && (
          <path
            d={`M ${parentX + 140} ${parentY} C ${parentX + 160} ${parentY}, ${x - 20} ${y}, ${x} ${y}`}
            stroke={isSelected ? "#3b82f6" : "#64748b"}
            strokeWidth="2"
            fill="none"
          />
        )}
        
        {/* Node */}
        <g
          onClick={() => setSelectedNode(node.id)}
          style={{ cursor: 'pointer' }}
        >
          <rect
            x={x}
            y={y - 20}
            width={140}
            height={40}
            rx={8}
            fill={isSelected ? "#3b82f680" : "#1e293b80"}
            stroke={isSelected ? "#3b82f6" : "#64748b"}
            strokeWidth="2"
          />
          <text
            x={x + 70}
            y={y + 5}
            textAnchor="middle"
            fill="#f8fafc"
            fontSize="14"
          >
            {node.text}
          </text>
          
          {/* Delete button (except for root node) */}
          {!isRoot && (
            <g
              onClick={(e) => {
                e.stopPropagation();
                deleteNode(node.id);
              }}
              style={{ cursor: 'pointer' }}
            >
              <circle
                cx={x + 130}
                cy={y - 15}
                r={8}
                fill="#ef4444"
                opacity={0.8}
              />
              <text
                x={x + 130}
                y={y - 12}
                textAnchor="middle"
                fill="#ffffff"
                fontSize="12"
                fontWeight="bold"
              >
                ×
              </text>
            </g>
          )}
        </g>
        
        {/* Children */}
        {node.children.map((child, index) => {
          const childY = startY + index * childHeight;
          return renderNode(child, level + 1, x, childY);
        })}
      </g>
    );
  };
  
  // Function to export the mind map as a PNG image
  const exportAsPng = () => {
    if (!mapContainerRef.current) return;
    
    const svg = mapContainerRef.current.querySelector('svg');
    const serializer = new XMLSerializer();
    const svgData = serializer.serializeToString(svg);
    
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = svg.width.baseVal.value;
    canvas.height = svg.height.baseVal.value;
    
    const image = new Image();
    image.onload = () => {
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(image, 0, 0);
      
      const link = document.createElement('a');
      link.download = 'mindmap.png';
      link.href = canvas.toDataURL('image/png');
      link.click();
      
      toast({
        title: 'Success',
        description: 'Mind map exported as PNG',
      });
    };
    
    image.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
  };
  
  // Calculate SVG dimensions based on mind map complexity
  const svgWidth = 2000; // Fixed width
  const svgHeight = Math.max(600, (countAllNodes(mindMap) * 50)); // Dynamic height based on node count
  
  // Helper function to count all nodes in the mind map
  function countAllNodes(node) {
    let count = 1; // Count the current node
    if (node.children) {
      node.children.forEach(child => {
        count += countAllNodes(child);
      });
    }
    return count;
  }
  
  return (
    <div className="flex flex-col h-full bg-slate-900 text-white">
      {/* Toolbar */}
      <div className="flex items-center justify-between p-4 bg-slate-800 rounded-md mb-2">
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => exportAsPng()}
            className="flex items-center gap-1"
          >
            <Download size={16} />
            Export PNG
          </Button>
          
          <Button 
            variant="outline" 
            size="sm"
            className="flex items-center gap-1"
          >
            <Share2 size={16} />
            Share
          </Button>
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => setZoom(prev => Math.max(0.5, prev - 0.1))}
            disabled={zoom <= 0.5}
          >
            <ZoomOut size={16} />
          </Button>
          
          <span className="w-12 text-center">{Math.round(zoom * 100)}%</span>
          
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => setZoom(prev => Math.min(2, prev + 0.1))}
            disabled={zoom >= 2}
          >
            <ZoomIn size={16} />
          </Button>
        </div>
      </div>
      
      <div className="flex flex-1">
        {/* Mind map canvas */}
        <div 
          className="flex-1 overflow-auto border border-slate-700 rounded-md"
          ref={mapContainerRef}
          style={{ backgroundColor: '#0f172a' }}
        >
          <svg 
            width={svgWidth} 
            height={svgHeight} 
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          >
            <g transform={`translate(${svgWidth/2 - 600}, 0)`}>
              {renderNode(mindMap)}
            </g>
          </svg>
        </div>
        
        {/* Side panel for adding nodes */}
        <div className="w-64 p-4 bg-slate-800 border-l border-slate-700">
          <h3 className="text-lg font-semibold mb-4">Add New Node</h3>
          
          {selectedNode ? (
            <>
              <p className="text-sm text-slate-400 mb-2">
                Adding to: {findNodeById(mindMap, selectedNode)?.text || ''}
              </p>
              
              <Input 
                placeholder="Enter node text"
                value={newNodeText}
                onChange={(e) => setNewNodeText(e.target.value)}
                className="mb-2"
              />
              
              <Button 
                onClick={addChildNode}
                disabled={!newNodeText.trim()}
                className="w-full flex items-center justify-center gap-1"
              >
                <PlusCircle size={16} />
                Add Node
              </Button>
            </>
          ) : (
            <p className="text-sm text-slate-400">
              Select a node in the mind map to add children to it.
            </p>
          )}
          
          <Separator className="my-4" />
          
          <h3 className="text-lg font-semibold mb-2">Mind Map Tutorial</h3>
          <ul className="text-sm text-slate-400 list-disc pl-4 space-y-1">
            <li>Click on any node to select it</li>
            <li>Add new connected nodes from the side panel</li>
            <li>Click the "X" to delete a node and its children</li>
            <li>Use zoom controls to adjust the view</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default SimpleMindMap;