
import { create } from 'zustand';
import { Node, Edge } from 'reactflow';
import { nanoid } from 'nanoid';

interface MindMapState {
  nodes: Node[];
  edges: Edge[];
  addNode: (node: Node) => void;
  addEdge: (edge: Edge) => void;
  updateNode: (nodeId: string, data: Partial<Node>) => void;
  updateEdge: (edgeId: string, data: Partial<Edge>) => void;
  removeNode: (nodeId: string) => void;
  removeEdge: (edgeId: string) => void;
  setNodes: (nodes: Node[]) => void;
  setEdges: (edges: Edge[]) => void;
}

export const useMindMapStore = create<MindMapState>((set) => ({
  nodes: [],
  edges: [],
  
  addNode: (node) => set((state) => ({ 
    nodes: [...state.nodes, { ...node, id: node.id || nanoid() }] 
  })),
  
  addEdge: (edge) => set((state) => ({ 
    edges: [...state.edges, { ...edge, id: edge.id || nanoid() }] 
  })),
  
  updateNode: (nodeId, data) => set((state) => ({
    nodes: state.nodes.map((node) => 
      node.id === nodeId ? { ...node, ...data } : node
    )
  })),
  
  updateEdge: (edgeId, data) => set((state) => ({
    edges: state.edges.map((edge) => 
      edge.id === edgeId ? { ...edge, ...data } : edge
    )
  })),
  
  removeNode: (nodeId) => set((state) => ({
    nodes: state.nodes.filter((node) => node.id !== nodeId),
    edges: state.edges.filter(
      (edge) => edge.source !== nodeId && edge.target !== nodeId
    )
  })),
  
  removeEdge: (edgeId) => set((state) => ({
    edges: state.edges.filter((edge) => edge.id !== edgeId)
  })),
  
  setNodes: (nodes) => set({ nodes }),
  setEdges: (edges) => set({ edges })
}));
