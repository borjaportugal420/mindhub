import { createContext, useContext, useEffect, useState, ReactNode } from 'react';

export type Theme = 'dark' | 'light' | 'system';

export interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const initialThemeState: ThemeContextType = {
  theme: 'system',
  setTheme: () => null,
};

export const ThemeContext = createContext<ThemeContextType>(initialThemeState);

interface ThemeProviderProps {
  children: ReactNode;
  defaultTheme?: Theme;
}

function applyTheme(theme: Theme) {
  const root = window.document.documentElement;
  root.classList.remove('light', 'dark');
  
  if (theme === 'system') {
    const systemTheme = window.matchMedia('(prefers-color-scheme: dark')
      .matches
      ? 'dark'
      : 'light';
    root.classList.add(systemTheme);
  } else {
    root.classList.add(theme);
  }
}

export function ThemeProvider(props: ThemeProviderProps) {
  const { children, defaultTheme = 'system' } = props;
  const storedTheme = typeof window !== 'undefined' ? 
    (localStorage.getItem('theme') as Theme || defaultTheme) : 
    defaultTheme;
  
  const [theme, setTheme] = useState<Theme>(storedTheme);
  
  // Apply theme whenever it changes
  useEffect(() => {
    applyTheme(theme);
  }, [theme]);
  
  // Initialize on mount
  useEffect(() => {
    applyTheme(storedTheme);
  }, [storedTheme]);
  
  const value = {
    theme,
    setTheme: (newTheme: Theme) => {
      localStorage.setItem('theme', newTheme);
      setTheme(newTheme);
    },
  };
  
  return {
    Provider: ThemeContext.Provider,
    value,
    children
  };
}

export const useTheme = () => {
  const context = useContext(ThemeContext);
  
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  
  return context;
};
